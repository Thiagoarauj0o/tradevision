"use client";

import React, { useState } from "react";
import type { SuperOpportunityItem } from "@/lib/market-engine";
import {
  BookOpen,
  Globe,
  ExternalLink,
  Sparkles,
  RefreshCw,
  Award,
  Copy,
  Check,
} from "lucide-react";

export interface KnowledgeBookItem {
  id: number;
  code: string;
  title: string;
  author: string;
  coreMethod: string;
  quantitativeRules: string;
  roboImplementation: string;
  chartIndicatorTag: string;
  masteryPercent: number;
  neuralWeight: number;
  patternsValidated: number;
  winRateBoost: number;
}

export interface PortalFeedItem {
  id: number;
  portalCode: string;
  portalName: string;
  sourceUrl: string;
  headline: string;
  marketMetricLabel: string;
  marketMetricValue: string;
  technicalConsensus: string;
  sentimentScore: number;
  impactedTickers: string;
  opportunityAction: string;
  bookConfluenceRef: string;
  syncedAt: string;
}

interface BooksAndPortalsHubProps {
  books: KnowledgeBookItem[];
  portalFeeds: PortalFeedItem[];
  superOpportunities: SuperOpportunityItem[];
  onTrainBook: (bookCode: string) => Promise<void>;
  onSyncPortals: (portalCode: string) => Promise<void>;
  onSelectSymbol: (symbol: string) => void;
  onExecuteOpportunity: (opp: SuperOpportunityItem) => void;
  isTrainingBook: boolean;
  isSyncingPortals: boolean;
}

export default function BooksAndPortalsHub({
  books,
  portalFeeds,
  superOpportunities,
  onTrainBook,
  onSyncPortals,
  onSelectSymbol,
  onExecuteOpportunity,
  isTrainingBook,
  isSyncingPortals,
}: BooksAndPortalsHubProps) {
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  const officialPortals = [
    {
      code: "INFOMONEY_IBOV",
      name: "1. InfoMoney — Cotações B3 / Índice Ibovespa",
      url: "https://www.infomoney.com.br/cotacoes/b3/indice/ibovespa/",
      role: "Notícias corporativas em tempo real, maiores altas e baixas do Ibovespa, giro financeiro por corretora e fatos relevantes.",
      badgeColor: "#38BDF8",
    },
    {
      code: "B3_OFICIAL_IBOV",
      name: "2. B3 Oficial — Market Data & Índice Ibovespa",
      url: "https://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/ibovespa.htm",
      role: "Metodologia oficial da Carteira Teórica (80% do volume B3), Índice de Negociabilidade (IN), ponderação de Blue Chips e fluxo institucional.",
      badgeColor: "#00E676",
    },
    {
      code: "INVESTING_BR_BOVESPA",
      name: "3. Investing.com Brasil — Índices Bovespa",
      url: "https://br.investing.com/indices/bovespa",
      role: "Consenso quantitativo de 12 Médias Móveis e 10 Osciladores Técnicos em múltiplos tempos gráficos (5m, 15m, 1h, Diário) e correlação global.",
      badgeColor: "#F59E0B",
    },
  ];

  const handleCopy = (url: string) => {
    if (typeof navigator !== "undefined" && navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedUrl(url);
      setTimeout(() => setCopiedUrl(null), 2500);
    }
  };

  const formatPrice = (val: number) => {
    if (val >= 10000)
      return val.toLocaleString("pt-BR", { maximumFractionDigits: 0 });
    if (val < 10)
      return val.toLocaleString("pt-BR", {
        minimumFractionDigits: 3,
        maximumFractionDigits: 3,
      });
    return val.toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  return (
    <div className="space-y-4">
      {/* BLOCK 1: OS 3 ENDEREÇOS OFICIAIS DOS SITES DE NOTÍCIAS E DADOS DO MERCADO */}
      <div className="bg-[#0D121B] border-2 border-[#38BDF8]/50 rounded-md p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded bg-[#38BDF8]/15 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-mono font-bold uppercase text-[#F8FAFC]">
                ENDEREÇOS DOS SITES OFICIAIS CONECTADOS AO ROBÔ 1 (INFOMONEY • B3 • INVESTING.COM)
              </h2>
              <p className="text-xs text-[#94A3B8]">
                Links diretos e dados em tempo real utilizados pela IA para filtrar notícias e confirmar oportunidades de compra e venda.
              </p>
            </div>
          </div>

          <button
            onClick={() => onSyncPortals("TODOS")}
            disabled={isSyncingPortals}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-mono font-bold rounded bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90 transition-all cursor-pointer"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isSyncingPortals ? "animate-spin" : ""}`}
            />
            {isSyncingPortals
              ? "SINCRONIZANDO PORTAIS..."
              : "SINCRONIZAR OS 3 SITES AGORA"}
          </button>
        </div>

        {/* 3 Official Portal Cards with Explicit Full URLs */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {officialPortals.map((portal) => (
            <div
              key={portal.code}
              className="bg-[#070A0F] border border-[#1E293B] hover:border-[#38BDF8] rounded-md p-3.5 flex flex-col justify-between gap-3"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span
                    className="text-xs font-mono font-bold"
                    style={{ color: portal.badgeColor }}
                  >
                    {portal.name}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30">
                    ONLINE 24/7
                  </span>
                </div>

                {/* Explicit Full URL Box */}
                <div className="bg-[#131B29] border border-[#1E293B] rounded p-2 font-mono text-[11px] break-all flex items-center justify-between gap-2">
                  <a
                    href={portal.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#38BDF8] hover:underline font-bold"
                  >
                    {portal.url}
                  </a>
                  <button
                    onClick={() => handleCopy(portal.url)}
                    className="p-1 rounded bg-[#070A0F] text-[#94A3B8] hover:text-[#F8FAFC] shrink-0 cursor-pointer"
                    title="Copiar Endereço do Site"
                  >
                    {copiedUrl === portal.url ? (
                      <Check className="w-3.5 h-3.5 text-[#00E676]" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                <p className="text-xs text-[#CBD5E1] leading-relaxed">
                  {portal.role}
                </p>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <a
                  href={portal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-1.5 px-2.5 rounded bg-[#131B29] border border-[#38BDF8]/40 text-[#38BDF8] hover:bg-[#38BDF8] hover:text-[#070A0F] text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  ABRIR SITE OFICIAL
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => onSyncPortals(portal.code)}
                  disabled={isSyncingPortals}
                  className="py-1.5 px-2.5 rounded bg-[#0D121B] border border-[#1E293B] text-[#E2E8F0] hover:border-[#00E676] text-xs font-mono cursor-pointer"
                >
                  EXTRAIR DADOS
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Live Intelligence Extracted from the 3 Portals */}
        <div className="space-y-2 pt-1">
          <div className="text-xs font-mono font-bold text-[#94A3B8] uppercase">
            Últimas Leituras Extraídas dos 3 Sites pelo Robô 1:
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {portalFeeds.slice(0, 6).map((feed) => {
              const isBuy = feed.technicalConsensus.includes("COMPRA");
              return (
                <div
                  key={feed.id}
                  className="bg-[#070A0F] border border-[#1E293B] rounded p-3 flex flex-col justify-between gap-2"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-1">
                      <a
                        href={feed.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[10px] font-mono font-bold text-[#38BDF8] hover:underline flex items-center gap-1 truncate"
                      >
                        {feed.portalName}
                        <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                      </a>
                      <span
                        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded shrink-0 ${
                          isBuy
                            ? "bg-[#00E676]/15 text-[#00E676]"
                            : "bg-[#FF2E54]/15 text-[#FF2E54]"
                        }`}
                      >
                        {feed.technicalConsensus}
                      </span>
                    </div>

                    <div className="text-[10px] font-mono text-[#64748B] truncate">
                      Fonte: {feed.sourceUrl}
                    </div>

                    <p className="text-xs font-semibold text-[#F8FAFC] leading-snug">
                      {feed.headline}
                    </p>

                    <div className="bg-[#131B29] px-2 py-1 rounded text-[11px] font-mono text-[#CBD5E1]">
                      <strong className="text-[#F59E0B]">
                        {feed.marketMetricLabel}:
                      </strong>{" "}
                      {feed.marketMetricValue}
                    </div>
                  </div>

                  <div className="space-y-1 border-t border-[#1E293B] pt-2 text-[11px]">
                    <div className="text-[#00E676] font-mono font-semibold">
                      🎯 {feed.opportunityAction}
                    </div>
                    <div className="text-[#94A3B8] font-mono text-[10px]">
                      📚 {feed.bookConfluenceRef}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* BLOCK 2: BIBLIOTECA NEURAL DOS 7 LIVROS MESTRES */}
      <div className="bg-[#0D121B] border border-[#1E293B] rounded-md p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded bg-[#F59E0B]/15 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B]">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-mono font-bold uppercase text-[#F8FAFC]">
                BASE DE CONHECIMENTO LITERÁRIO DO ROBÔ 1 — OS 7 LIVROS CLÁSSICOS DO MERCADO FINANCEIRO
              </h2>
              <p className="text-xs text-[#94A3B8]">
                Todos os ensinamentos abaixo foram convertidos em algoritmos matemáticos ativos 24h nos gráficos, na aba de previsão e no radar de compra/venda.
              </p>
            </div>
          </div>

          <button
            onClick={() => onTrainBook("TODOS")}
            disabled={isTrainingBook}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-mono font-bold rounded bg-[#F59E0B] text-[#070A0F] hover:bg-[#F59E0B]/90 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {isTrainingBook
              ? "APROFUNDANDO LEITURA IA..."
              : "REFORÇAR APRENDIZADO DOS 7 LIVROS NO ROBÔ 1"}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {books.map((book, index) => (
            <div
              key={book.code}
              className="bg-[#070A0F] border border-[#1E293B] hover:border-[#F59E0B]/60 rounded-md p-3.5 flex flex-col justify-between gap-3"
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30">
                      LIVRO #{index + 1} • ASSIMILADO {book.masteryPercent.toFixed(1)}%
                    </span>
                    <h3 className="text-xs font-mono font-bold text-[#F8FAFC] mt-1.5">
                      “{book.title}”
                    </h3>
                    <div className="text-[11px] text-[#38BDF8] font-mono">
                      Autor: {book.author}
                    </div>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-[#00E676] shrink-0">
                    +{book.winRateBoost}% Acerto
                  </span>
                </div>

                <div className="bg-[#131B29] p-2 rounded border border-[#1E293B] text-[11px] space-y-1">
                  <div className="text-[#F59E0B] font-mono font-bold">
                    Método Central:
                  </div>
                  <p className="text-[#E2E8F0] leading-snug">{book.coreMethod}</p>
                </div>

                <div className="text-[11px] text-[#CBD5E1] space-y-1">
                  <div className="font-mono font-bold text-[#38BDF8]">
                    Regras Quantitativas Extraídas:
                  </div>
                  <p className="leading-snug">{book.quantitativeRules}</p>
                </div>

                <div className="text-[11px] text-[#94A3B8] bg-[#0D121B] p-2 rounded border border-[#1E293B]">
                  <strong className="text-[#00E676] font-mono">
                    Aplicação no Robô 1:{" "}
                  </strong>
                  {book.roboImplementation}
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#1E293B]">
                <span className="text-[10px] font-mono text-[#94A3B8]">
                  Padrões Validados:{" "}
                  <strong className="text-[#F8FAFC]">
                    {book.patternsValidated}
                  </strong>
                </span>
                <button
                  onClick={() => onTrainBook(book.code)}
                  disabled={isTrainingBook}
                  className="px-2.5 py-1 rounded bg-[#131B29] border border-[#F59E0B]/40 text-[#F59E0B] hover:bg-[#F59E0B] hover:text-[#070A0F] text-[10px] font-mono font-bold transition-colors cursor-pointer"
                >
                  TREINAR ROBÔ NESTE LIVRO
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* BLOCK 3: MATRIZ DECISÓRIA DAS MELHORES OPORTUNIDADES (7 LIVROS + 3 PORTAIS) */}
      <div className="bg-[#0D121B] border border-[#00E676]/40 rounded-md p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#1E293B] pb-3">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-[#00E676]" />
            <div>
              <h2 className="text-sm font-mono font-bold uppercase text-[#F8FAFC]">
                MATRIZ DECISÓRIA: AS MELHORES OPORTUNIDADES DE COMPRA E VENDA AGORA
              </h2>
              <p className="text-xs text-[#94A3B8]">
                Cruzamento simultâneo dos 7 Livros Clássicos + InfoMoney IBOV + B3 Oficial + Investing.com Brasil
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-mono text-xs">
            <thead>
              <tr className="border-b border-[#1E293B] bg-[#070A0F] text-[#94A3B8] text-[10px]">
                <th className="py-2.5 px-2.5">ATIVO / PESO B3</th>
                <th className="py-2.5 px-2.5">SINAL ROBÔ 1</th>
                <th className="py-2.5 px-2.5">ENTRADA</th>
                <th className="py-2.5 px-2.5 text-[#FF2E54]">
                  STOP 2N (TURTLE)
                </th>
                <th className="py-2.5 px-2.5 text-[#00E676]">
                  ALVO FIBO 161.8%
                </th>
                <th className="py-2.5 px-2.5">CONSENSO INVESTING.COM</th>
                <th className="py-2.5 px-2.5">PADRÃO BULKOWSKI & LIVROS</th>
                <th className="py-2.5 px-2.5">AÇÃO</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E293B]">
              {superOpportunities.map((opp) => {
                const isBuy = opp.action.includes("COMPRA");
                return (
                  <tr key={opp.symbol} className="hover:bg-[#131B29]/60">
                    <td className="py-2.5 px-2.5">
                      <div className="font-bold text-[#F8FAFC]">
                        {opp.symbol}
                      </div>
                      <div className="text-[10px] text-[#38BDF8]">
                        {opp.b3WeightPercent}
                      </div>
                    </td>
                    <td className="py-2.5 px-2.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          isBuy
                            ? "bg-[#00E676] text-[#070A0F]"
                            : "bg-[#FF2E54] text-white"
                        }`}
                      >
                        {opp.action} ({opp.convictionScore}%)
                      </span>
                    </td>
                    <td className="py-2.5 px-2.5 font-bold text-[#F8FAFC]">
                      {opp.currency} {formatPrice(opp.entryZone)}
                    </td>
                    <td className="py-2.5 px-2.5 font-bold text-[#FF2E54]">
                      {opp.currency} {formatPrice(opp.turtleStop2N)}
                    </td>
                    <td className="py-2.5 px-2.5 font-bold text-[#00E676]">
                      {opp.currency} {formatPrice(opp.targetFib1618)}
                    </td>
                    <td className="py-2.5 px-2.5 text-[11px] text-[#CBD5E1]">
                      {opp.investingTechnicalSummary}
                    </td>
                    <td className="py-2.5 px-2.5 text-[11px] text-[#F59E0B]">
                      {opp.bookChecklist.bulkowskiCandle} • Triple Screen OK
                    </td>
                    <td className="py-2.5 px-2.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => onSelectSymbol(opp.symbol)}
                          className="px-2 py-1 rounded bg-[#131B29] text-[#38BDF8] border border-[#1E293B] hover:border-[#38BDF8] text-[10px] font-bold cursor-pointer"
                        >
                          GRÁFICO
                        </button>
                        <button
                          onClick={() => onExecuteOpportunity(opp)}
                          className={`px-2.5 py-1 rounded text-[10px] font-bold cursor-pointer ${
                            isBuy
                              ? "bg-[#00E676] text-[#070A0F]"
                              : "bg-[#FF2E54] text-white"
                          }`}
                        >
                          EXECUTAR
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
