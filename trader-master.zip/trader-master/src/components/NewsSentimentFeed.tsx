"use client";

import React, { useState } from "react";
import {
  Newspaper,
  Globe2,
  MapPin,
  TrendingUp,
  TrendingDown,
  Send,
  Sparkles,
  Bot,
} from "lucide-react";

export interface NewsEventItem {
  id: number;
  title: string;
  source: string;
  region: string;
  impactLevel: string;
  sentiment: string;
  sentimentScore: number;
  relatedAssets: string;
  aiAnalysis: string;
  publishedAt: string;
}

interface NewsSentimentFeedProps {
  news: NewsEventItem[];
  onSelectSymbol: (symbol: string) => void;
  onIngestNews: (payload: {
    title: string;
    region: string;
    source: string;
    relatedAssets: string;
  }) => Promise<void>;
  isSubmittingNews: boolean;
}

export default function NewsSentimentFeed({
  news,
  onSelectSymbol,
  onIngestNews,
  isSubmittingNews,
}: NewsSentimentFeedProps) {
  const [regionFilter, setRegionFilter] = useState<"TODAS" | "BRASIL" | "MUNDO">(
    "TODAS"
  );
  const [showForm, setShowForm] = useState<boolean>(false);
  const [headline, setHeadline] = useState<string>("");
  const [region, setRegion] = useState<string>("BRASIL");
  const [relatedAssets, setRelatedAssets] = useState<string>("PETR4.SA,WINJ26");

  const filteredNews = news.filter((item) =>
    regionFilter === "TODAS" ? true : item.region === regionFilter
  );

  // Aggregate NLP sentiment index for Brazil and Global
  const brNews = news.filter((n) => n.region === "BRASIL");
  const globalNews = news.filter((n) => n.region === "MUNDO");
  const brAvg =
    brNews.length > 0
      ? Math.round(
          brNews.reduce((acc, n) => acc + n.sentimentScore, 0) / brNews.length
        )
      : 54;
  const globalAvg =
    globalNews.length > 0
      ? Math.round(
          globalNews.reduce((acc, n) => acc + n.sentimentScore, 0) /
            globalNews.length
        )
      : 68;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!headline.trim()) return;
    await onIngestNews({
      title: headline,
      region,
      source:
        region === "BRASIL"
          ? "Broadcast B3 / Valor Tempo Real"
          : "Reuters / Bloomberg Global",
      relatedAssets,
    });
    setHeadline("");
    setShowForm(false);
  };

  return (
    <div className="bg-[#0D121B] border border-[#1E293B] rounded-md flex flex-col h-full">
      {/* Header */}
      <div className="p-3.5 border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Newspaper className="w-4 h-4 text-[#F59E0B]" />
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#F8FAFC]">
            RADAR DE NOTÍCIAS BRASIL & MUNDO (NLP ROBÔ 1)
          </h3>
        </div>

        <div className="flex items-center gap-1.5">
          {(["TODAS", "BRASIL", "MUNDO"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setRegionFilter(tab)}
              className={`px-2 py-1 text-[11px] font-mono rounded transition-colors cursor-pointer ${
                regionFilter === tab
                  ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                  : "bg-[#070A0F] text-[#94A3B8] hover:text-[#F8FAFC] border border-[#1E293B]"
              }`}
            >
              {tab === "BRASIL" ? "🇧🇷 BRASIL" : tab === "MUNDO" ? "🌐 MUNDO" : "TODAS"}
            </button>
          ))}

          <button
            onClick={() => setShowForm(!showForm)}
            className="px-2 py-1 text-[11px] font-mono rounded bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/40 hover:bg-[#F59E0B]/25 cursor-pointer"
          >
            + TESTAR NOTÍCIA NA IA
          </button>
        </div>
      </div>

      {/* Macro Sentiment Thermometers (Brazil vs World) */}
      <div className="grid grid-cols-2 gap-2 px-3.5 py-2 bg-[#070A0F] border-b border-[#1E293B] text-xs font-mono">
        <div className="flex items-center justify-between bg-[#0D121B] px-2.5 py-1.5 rounded border border-[#1E293B]">
          <span className="text-[#94A3B8] flex items-center gap-1">
            <MapPin className="w-3 h-3 text-[#00E676]" /> Sentimento Brasil:
          </span>
          <span
            className={`font-bold ${
              brAvg >= 0 ? "text-[#00E676]" : "text-[#FF2E54]"
            }`}
          >
            {brAvg >= 0 ? `+${brAvg}` : brAvg} pts ({brAvg >= 0 ? "OTIMISTA" : "CAUTELA"})
          </span>
        </div>

        <div className="flex items-center justify-between bg-[#0D121B] px-2.5 py-1.5 rounded border border-[#1E293B]">
          <span className="text-[#94A3B8] flex items-center gap-1">
            <Globe2 className="w-3 h-3 text-[#38BDF8]" /> Sentimento Mundo:
          </span>
          <span
            className={`font-bold ${
              globalAvg >= 0 ? "text-[#00E676]" : "text-[#FF2E54]"
            }`}
          >
            {globalAvg >= 0 ? `+${globalAvg}` : globalAvg} pts (
            {globalAvg >= 0 ? "RISK-ON" : "RISK-OFF"})
          </span>
        </div>
      </div>

      {/* Interactive News Injection Form */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="p-3 bg-[#131B29] border-b border-[#38BDF8]/40 space-y-2.5"
        >
          <div className="text-xs font-mono font-bold text-[#38BDF8] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            ALIMENTAR ROBÔ 1 COM NOVO FATO RELEVANTE (BRASIL OU MUNDO)
          </div>
          <input
            type="text"
            value={headline}
            onChange={(e) => setHeadline(e.target.value)}
            placeholder="Ex: COPOM sinaliza queda da Selic e fluxo estrangeiro dispara na B3..."
            className="w-full bg-[#070A0F] border border-[#1E293B] rounded px-2.5 py-1.5 text-xs text-[#F8FAFC] focus:outline-none focus:border-[#38BDF8]"
            required
          />
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={region}
              onChange={(e) => {
                setRegion(e.target.value);
                setRelatedAssets(
                  e.target.value === "BRASIL"
                    ? "PETR4.SA,WINJ26,USD/BRL"
                    : "BTC/USDT,NVDA,ETH/USDT"
                );
              }}
              className="bg-[#070A0F] border border-[#1E293B] rounded px-2 py-1 text-xs font-mono text-[#F8FAFC]"
            >
              <option value="BRASIL">Região: BRASIL (B3 / BCB)</option>
              <option value="MUNDO">Região: MUNDO (Global / EUA / Cripto)</option>
            </select>

            <input
              type="text"
              value={relatedAssets}
              onChange={(e) => setRelatedAssets(e.target.value)}
              placeholder="Ativos: PETR4.SA,WINJ26"
              className="bg-[#070A0F] border border-[#1E293B] rounded px-2 py-1 text-xs font-mono text-[#F8FAFC] flex-1 min-w-[140px]"
            />

            <button
              type="submit"
              disabled={isSubmittingNews}
              className="inline-flex items-center gap-1 px-3 py-1 text-xs font-mono font-bold rounded bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90 cursor-pointer"
            >
              <Send className="w-3 h-3" />
              {isSubmittingNews ? "PROCESSANDO..." : "ANALISAR COM IA"}
            </button>
          </div>
        </form>
      )}

      {/* News List */}
      <div className="p-3 space-y-2.5 overflow-y-auto max-h-[430px]">
        {filteredNews.map((item) => {
          const isBull = item.sentiment === "BULLISH";
          const tickers = item.relatedAssets
            .split(",")
            .map((t) => t.trim())
            .filter(Boolean);

          return (
            <div
              key={item.id}
              className="bg-[#070A0F] border border-[#1E293B] hover:border-[#38BDF8]/40 rounded p-3 transition-colors space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span
                    className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
                      item.region === "BRASIL"
                        ? "bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30"
                        : "bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30"
                    }`}
                  >
                    {item.region === "BRASIL" ? "🇧🇷 BRASIL" : "🌐 MUNDO"}
                  </span>
                  <span className="text-[11px] font-mono text-[#64748B]">
                    {item.source}
                  </span>
                </div>

                <span
                  className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                    isBull
                      ? "bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30"
                      : "bg-[#FF2E54]/15 text-[#FF2E54] border border-[#FF2E54]/30"
                  }`}
                >
                  {isBull ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  NLP {item.sentimentScore > 0 ? `+${item.sentimentScore}` : item.sentimentScore}
                </span>
              </div>

              <h4 className="text-xs font-semibold text-[#F8FAFC] leading-snug">
                {item.title}
              </h4>

              {/* Robô 1 Interpretation Box */}
              <div className="bg-[#131B29]/90 border-l-2 border-[#38BDF8] px-2.5 py-1.5 rounded-r text-[11px] text-[#CBD5E1] flex items-start gap-2">
                <Bot className="w-3.5 h-3.5 text-[#38BDF8] shrink-0 mt-0.5" />
                <span>{item.aiAnalysis}</span>
              </div>

              {/* Impacted Asset Pills */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                <div className="flex flex-wrap items-center gap-1">
                  <span className="text-[10px] font-mono text-[#64748B]">
                    Ativos Impactados:
                  </span>
                  {tickers.map((ticker) => (
                    <button
                      key={ticker}
                      onClick={() => onSelectSymbol(ticker)}
                      className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#131B29] text-[#38BDF8] border border-[#1E293B] hover:border-[#38BDF8] cursor-pointer"
                    >
                      {ticker}
                    </button>
                  ))}
                </div>
                <span className="text-[10px] font-mono text-[#F59E0B]">
                  IMPACTO {item.impactLevel}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
