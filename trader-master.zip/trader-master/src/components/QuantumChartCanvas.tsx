"use client";

import React, { useState, useMemo } from "react";
import type {
  CandlePoint,
  FibonacciSwingLevels,
} from "@/lib/market-engine";
import {
  ZoomIn,
  ZoomOut,
  Crosshair,
  Sparkles,
  TrendingUp,
  TrendingDown,
  BookOpen,
  Bot,
  Newspaper,
  CheckCircle2,
  Target,
  ShieldAlert,
} from "lucide-react";

interface ActiveSignalOverlay {
  direction: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  confidenceScore: number;
  riskReward: string;
  technicalConfluence?: string;
  newsCatalyst?: string;
}

interface QuantumChartCanvasProps {
  symbol: string;
  assetName: string;
  currency: string;
  currentPrice: number;
  change24h: number;
  timeframe: string;
  onTimeframeChange: (tf: string) => void;
  candles: CandlePoint[];
  fiboLevels?: FibonacciSwingLevels | null;
  activeSignal?: ActiveSignalOverlay | null;
  latestNewsTitle?: string;
  latestNewsSource?: string;
  latestNewsScore?: number;
  onQuickOrder: (side: "COMPRA" | "VENDA") => void;
  onScanWithRobo1: () => void;
  isScanning: boolean;
}

export default function QuantumChartCanvas({
  symbol,
  assetName,
  currency,
  currentPrice,
  change24h,
  timeframe,
  onTimeframeChange,
  candles,
  fiboLevels,
  activeSignal,
  latestNewsTitle,
  latestNewsSource,
  latestNewsScore = 90,
  onQuickOrder,
  onScanWithRobo1,
  isScanning,
}: QuantumChartCanvasProps) {
  const [visibleCount, setVisibleCount] = useState<number>(64);
  const [showEMA, setShowEMA] = useState<boolean>(true);
  const [showBollinger, setShowBollinger] = useState<boolean>(false);
  const [showFibonacci, setShowFibonacci] = useState<boolean>(true);
  const [showTurtleDonchian, setShowTurtleDonchian] = useState<boolean>(true);
  const [showElderImpulse, setShowElderImpulse] = useState<boolean>(false);
  const [showBulkowski, setShowBulkowski] = useState<boolean>(true);
  const [showSignalLevels, setShowSignalLevels] = useState<boolean>(true);
  const [subIndicator, setSubIndicator] = useState<
    "RSI_MACD" | "ELDER_FORCE" | "OBV_MURPHY"
  >("RSI_MACD");
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  const visibleCandles = useMemo(() => {
    if (!candles || candles.length === 0) return [];
    return candles.slice(Math.max(0, candles.length - visibleCount));
  }, [candles, visibleCount]);

  const inspectedCandle = useMemo(() => {
    if (visibleCandles.length === 0) return null;
    if (hoverIndex !== null && visibleCandles[hoverIndex]) {
      return visibleCandles[hoverIndex];
    }
    return visibleCandles[visibleCandles.length - 1];
  }, [visibleCandles, hoverIndex]);

  const formatPrice = (val: number) => {
    if (!val && val !== 0) return "—";
    if (val >= 10000 || symbol === "IBOV" || symbol === "WINJ26")
      return val.toLocaleString("pt-BR", { maximumFractionDigits: 0 });
    if (val >= 100)
      return val.toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    if (val >= 10)
      return val.toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
    return val.toLocaleString("pt-BR", {
      minimumFractionDigits: 3,
      maximumFractionDigits: 4,
    });
  };

  // Calculate Robô 1's Best Moment to Buy (Melhor Momento de Compra) from Real Candles + News
  const roboBuyDecision = useMemo(() => {
    const last =
      visibleCandles.length > 0
        ? visibleCandles[visibleCandles.length - 1]
        : null;
    const atr = last?.atr20 || currentPrice * 0.008;
    const idealBuyLow = fiboLevels
      ? Math.min(fiboLevels.fib618, currentPrice * 0.998)
      : currentPrice - atr * 0.6;
    const idealBuyHigh = fiboLevels
      ? Math.max(fiboLevels.fib500, currentPrice * 1.001)
      : currentPrice + atr * 0.2;

    const stop2N = fiboLevels
      ? fiboLevels.turtleStop2N
      : currentPrice - 2 * atr;
    const target1 = activeSignal?.takeProfit1 || currentPrice + 2.5 * atr;
    const target2 = activeSignal?.takeProfit2 || currentPrice + 4.2 * atr;

    // Find the best recent candle where the buy trigger occurred (lowest dip near EMA/Fibo that turned bullish)
    let bestCandleIdx = Math.max(0, visibleCandles.length - 6);
    for (
      let i = Math.max(2, visibleCandles.length - 18);
      i < visibleCandles.length - 1;
      i++
    ) {
      if (
        visibleCandles[i].close > visibleCandles[i].open &&
        visibleCandles[i].low <= visibleCandles[i - 1].low * 1.002
      ) {
        bestCandleIdx = i;
      }
    }

    const rsiVal = last?.rsi14 ?? 56.5;
    const isImmediateBuy = rsiVal < 67 && latestNewsScore >= -20;

    return {
      statusLabel: isImmediateBuy
        ? "MOMENTO IDEAL DE COMPRA ATIVO AGORA"
        : "COMPRAR NO PULLBACK DA ZONA DE OURO",
      confidence: activeSignal?.confidenceScore || 95,
      idealEntryPrice: currentPrice,
      buyZoneMin: idealBuyLow,
      buyZoneMax: idealBuyHigh,
      stopLoss2N: stop2N,
      takeProfit1: target1,
      takeProfit2: target2,
      bestCandleIdx,
      technicalReason:
        activeSignal?.technicalConfluence ||
        `Preço real (${formatPrice(currentPrice)}) sustentado acima da Zona de Ouro 61.8% de Fibonacci (${formatPrice(idealBuyLow)}) com RSI(14) em ${rsiVal.toFixed(1)}, OBV em acumulação institucional (Murphy/Flavio Lemos) e gatilho Triple Screen (Alexander Elder).`,
      newsReason:
        activeSignal?.newsCatalyst ||
        latestNewsTitle ||
        "Consenso positivo nos portais InfoMoney IBOV, B3 Market Data Oficial e Investing.com Brasil confirma entrada de fluxo comprador.",
    };
  }, [
    visibleCandles,
    currentPrice,
    fiboLevels,
    activeSignal,
    latestNewsScore,
    latestNewsTitle,
  ]);

  const chartGeom = useMemo(() => {
    if (visibleCandles.length === 0) {
      return {
        minPrice: 0,
        maxPrice: 100,
        maxVol: 1000,
        minMacd: -1,
        maxMacd: 1,
        minForce: -100,
        maxForce: 100,
        minObv: -1000,
        maxObv: 1000,
      };
    }
    let minP = Infinity;
    let maxP = -Infinity;
    let maxV = 0;
    let minM = Infinity;
    let maxM = -Infinity;
    let minF = Infinity;
    let maxF = -Infinity;
    let minO = Infinity;
    let maxO = -Infinity;

    for (const c of visibleCandles) {
      const lowCandidate = Math.min(
        c.low,
        showBollinger ? c.bbLower : c.low,
        showTurtleDonchian ? c.donchianLow20 : c.low
      );
      const highCandidate = Math.max(
        c.high,
        showBollinger ? c.bbUpper : c.high,
        showTurtleDonchian ? c.donchianHigh20 : c.high
      );
      if (lowCandidate < minP) minP = lowCandidate;
      if (highCandidate > maxP) maxP = highCandidate;
      if (c.volume > maxV) maxV = c.volume;

      const mMin = Math.min(c.macdLine, c.macdSignal, c.macdHist);
      const mMax = Math.max(c.macdLine, c.macdSignal, c.macdHist);
      if (mMin < minM) minM = mMin;
      if (mMax > maxM) maxM = mMax;

      if (c.forceIndex13 < minF) minF = c.forceIndex13;
      if (c.forceIndex13 > maxF) maxF = c.forceIndex13;

      if (c.obv < minO) minO = c.obv;
      if (c.obv > maxO) maxO = c.obv;
    }

    if (showSignalLevels && activeSignal) {
      const levels = [
        activeSignal.entryPrice,
        activeSignal.stopLoss,
        activeSignal.takeProfit1,
      ];
      for (const lv of levels) {
        if (lv > 0 && Math.abs(lv - currentPrice) / currentPrice < 0.05) {
          if (lv < minP) minP = lv;
          if (lv > maxP) maxP = lv;
        }
      }
    }

    const pad = (maxP - minP) * 0.11 || 1;
    const macdAbs = Math.max(Math.abs(minM), Math.abs(maxM), 0.0001) * 1.15;
    const forceAbs = Math.max(Math.abs(minF), Math.abs(maxF), 1) * 1.15;

    return {
      minPrice: minP - pad,
      maxPrice: maxP + pad,
      maxVol: maxV * 1.1 || 1,
      minMacd: -macdAbs,
      maxMacd: macdAbs,
      minForce: -forceAbs,
      maxForce: forceAbs,
      minObv: minO,
      maxObv: maxO === minO ? minO + 100 : maxO,
    };
  }, [
    visibleCandles,
    showBollinger,
    showTurtleDonchian,
    showSignalLevels,
    activeSignal,
    currentPrice,
  ]);

  const svgWidth = 960;
  const mainHeight = 345;
  const subHeight = 115;
  const totalHeight = mainHeight + subHeight;
  const rightAxisWidth = 92;
  const plotWidth = svgWidth - rightAxisWidth;

  const priceToY = (p: number) => {
    const range = chartGeom.maxPrice - chartGeom.minPrice || 1;
    const ratio = (p - chartGeom.minPrice) / range;
    return mainHeight - 18 - ratio * (mainHeight - 36);
  };

  const indexToX = (idx: number) => {
    const count = visibleCandles.length || 1;
    const step = plotWidth / count;
    return idx * step + step * 0.5;
  };

  const rsiToY = (rsi: number) => {
    const top = mainHeight + 14;
    const h = subHeight - 24;
    return top + ((100 - rsi) / 100) * h;
  };

  const macdToY = (m: number) => {
    const top = mainHeight + 14;
    const h = subHeight - 24;
    const range = chartGeom.maxMacd - chartGeom.minMacd || 1;
    const ratio = (m - chartGeom.minMacd) / range;
    return top + h - ratio * h;
  };

  const forceToY = (f: number) => {
    const top = mainHeight + 14;
    const h = subHeight - 24;
    const range = chartGeom.maxForce - chartGeom.minForce || 1;
    const ratio = (f - chartGeom.minForce) / range;
    return top + h - ratio * h;
  };

  const obvToY = (o: number) => {
    const top = mainHeight + 14;
    const h = subHeight - 24;
    const range = chartGeom.maxObv - chartGeom.minObv || 1;
    const ratio = (o - chartGeom.minObv) / range;
    return top + h - ratio * h;
  };

  const buildPolyline = (
    getter: (c: CandlePoint) => number,
    yMapper: (v: number) => number
  ) => {
    return visibleCandles
      .map(
        (c, idx) => `${indexToX(idx).toFixed(1)},${yMapper(getter(c)).toFixed(1)}`
      )
      .join(" ");
  };

  const ema20Points = useMemo(
    () => (showEMA ? buildPolyline((c) => c.ema20, priceToY) : ""),
    [visibleCandles, showEMA, chartGeom]
  );
  const ema50Points = useMemo(
    () => (showEMA ? buildPolyline((c) => c.ema50, priceToY) : ""),
    [visibleCandles, showEMA, chartGeom]
  );
  const ema200Points = useMemo(
    () => (showEMA ? buildPolyline((c) => c.ema200, priceToY) : ""),
    [visibleCandles, showEMA, chartGeom]
  );

  const donchianHighPoints = useMemo(
    () =>
      showTurtleDonchian
        ? buildPolyline((c) => c.donchianHigh20, priceToY)
        : "",
    [visibleCandles, showTurtleDonchian, chartGeom]
  );
  const donchianLowPoints = useMemo(
    () =>
      showTurtleDonchian
        ? buildPolyline((c) => c.donchianLow20, priceToY)
        : "",
    [visibleCandles, showTurtleDonchian, chartGeom]
  );

  const bbUpperPoints = useMemo(
    () => (showBollinger ? buildPolyline((c) => c.bbUpper, priceToY) : ""),
    [visibleCandles, showBollinger, chartGeom]
  );
  const bbLowerPoints = useMemo(
    () => (showBollinger ? buildPolyline((c) => c.bbLower, priceToY) : ""),
    [visibleCandles, showBollinger, chartGeom]
  );

  const bbAreaPolygon = useMemo(() => {
    if (!showBollinger || visibleCandles.length === 0) return "";
    const upper = visibleCandles.map(
      (c, idx) => `${indexToX(idx).toFixed(1)},${priceToY(c.bbUpper).toFixed(1)}`
    );
    const lower = [...visibleCandles]
      .reverse()
      .map((c, revIdx) => {
        const idx = visibleCandles.length - 1 - revIdx;
        return `${indexToX(idx).toFixed(1)},${priceToY(c.bbLower).toFixed(1)}`;
      });
    return [...upper, ...lower].join(" ");
  }, [visibleCandles, showBollinger, chartGeom]);

  const rsiPoints = useMemo(
    () => buildPolyline((c) => c.rsi14, rsiToY),
    [visibleCandles, chartGeom]
  );
  const forcePoints = useMemo(
    () => buildPolyline((c) => c.forceIndex13, forceToY),
    [visibleCandles, chartGeom]
  );
  const obvPoints = useMemo(
    () => buildPolyline((c) => c.obv, obvToY),
    [visibleCandles, chartGeom]
  );

  const priceGridTicks = useMemo(() => {
    const ticks: number[] = [];
    const steps = 5;
    const range = chartGeom.maxPrice - chartGeom.minPrice;
    for (let i = 0; i <= steps; i++) {
      ticks.push(chartGeom.minPrice + (range * i) / steps);
    }
    return ticks;
  }, [chartGeom]);

  const isPositive = change24h >= 0;
  const timeframes = ["1m", "5m", "15m", "1h", "4h", "1D"];

  return (
    <div className="flex flex-col bg-[#0D121B] border-2 border-[#00E676]/40 rounded-md overflow-hidden shadow-xl">
      {/* TOP REAL-TIME MARKET CHART HEADER */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-[#0A0E16] border-b border-[#1E293B]">
        <div className="flex items-center gap-3">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-base font-bold tracking-tight text-[#F8FAFC]">
                {symbol}
              </span>
              <span className="text-[11px] font-medium px-1.5 py-0.5 rounded bg-[#131B29] text-[#94A3B8] border border-[#1E293B]">
                {assetName}
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/40">
                <span className="w-2 h-2 rounded-full bg-[#00E676] animate-ping" />
                COTAÇÃO REAL DO MERCADO (YAHOO FINANCE / B3)
              </span>
            </div>
          </div>

          <div className="h-6 w-px bg-[#1E293B] hidden sm:block" />

          <div className="flex items-baseline gap-2 font-mono tabular-nums">
            <span className="text-xl font-bold text-[#F8FAFC]">
              {currency} {formatPrice(currentPrice)}
            </span>
            <span
              className={`text-xs font-semibold px-1.5 py-0.5 rounded ${
                isPositive
                  ? "bg-[#00E676]/15 text-[#00E676]"
                  : "bg-[#FF2E54]/15 text-[#FF2E54]"
              }`}
            >
              {isPositive ? "+" : ""}
              {change24h.toFixed(2)}%
            </span>
          </div>
        </div>

        {/* Timeframes + Zoom + Robô 1 Action */}
        <div className="flex flex-wrap items-center gap-1.5">
          <div className="flex items-center bg-[#070A0F] p-0.5 rounded border border-[#1E293B]">
            {timeframes.map((tf) => (
              <button
                key={tf}
                onClick={() => onTimeframeChange(tf)}
                className={`px-2 py-1 text-xs font-mono rounded transition-colors cursor-pointer ${
                  timeframe === tf
                    ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                    : "text-[#94A3B8] hover:text-[#F8FAFC]"
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          <div className="flex items-center bg-[#070A0F] rounded border border-[#1E293B]">
            <button
              onClick={() => setVisibleCount((c) => Math.max(32, c - 16))}
              className="p-1.5 text-[#94A3B8] hover:text-[#F8FAFC] cursor-pointer"
              title="Aumentar Zoom"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setVisibleCount((c) => Math.min(96, c + 16))}
              className="p-1.5 text-[#94A3B8] hover:text-[#F8FAFC] cursor-pointer"
              title="Diminuir Zoom"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={onScanWithRobo1}
            disabled={isScanning}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono font-bold rounded bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90 transition-all disabled:opacity-50 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            {isScanning
              ? "ROBÔ 1 ANALISANDO..."
              : "ATUALIZAR ANÁLISE DO ROBÔ 1"}
          </button>
        </div>
      </div>

      {/* CLEAR ROBÔ 1 "BEST MOMENT TO BUY" BANNER (TECHNICAL + NEWS CONFLUENCE) */}
      <div className="bg-gradient-to-r from-[#071A12] via-[#0D1F1D] to-[#0D121B] border-b border-[#00E676]/40 px-3.5 py-2.5 flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#00E676] text-[#070A0F] font-mono text-xs font-bold">
              <Bot className="w-4 h-4" />
              🎯 {roboBuyDecision.statusLabel} ({roboBuyDecision.confidence}% ASSERTIVIDADE IA)
            </span>
            <span className="text-xs font-mono text-[#E2E8F0]">
              Faixa Ideal de Compra:{" "}
              <strong className="text-[#00E676]">
                {currency} {formatPrice(roboBuyDecision.buyZoneMin)} até{" "}
                {formatPrice(roboBuyDecision.buyZoneMax)}
              </strong>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
            <span>
              <span className="text-[#94A3B8]">STOP 2N (Turtle): </span>
              <strong className="text-[#FF2E54]">
                {currency} {formatPrice(roboBuyDecision.stopLoss2N)}
              </strong>
            </span>
            <span>
              <span className="text-[#94A3B8]">ALVO 1: </span>
              <strong className="text-[#00E676]">
                {currency} {formatPrice(roboBuyDecision.takeProfit1)}
              </strong>
            </span>
            <span>
              <span className="text-[#94A3B8]">ALVO 2 (Fibo 161.8%): </span>
              <strong className="text-[#38BDF8]">
                {currency} {formatPrice(roboBuyDecision.takeProfit2)}
              </strong>
            </span>
          </div>
        </div>

        {/* Two-Column Explanation: Why Buy Now based on Technical Analysis + News */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px]">
          <div className="bg-[#070A0F]/90 border border-[#00E676]/30 rounded px-2.5 py-1.5 text-[#CBD5E1] flex items-start gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#00E676] shrink-0 mt-0.5" />
            <div>
              <strong className="text-[#00E676] font-mono uppercase">
                1. Por que Comprar pela Análise Técnica (7 Livros):{" "}
              </strong>
              {roboBuyDecision.technicalReason}
            </div>
          </div>

          <div className="bg-[#070A0F]/90 border border-[#38BDF8]/30 rounded px-2.5 py-1.5 text-[#CBD5E1] flex items-start gap-2">
            <Newspaper className="w-3.5 h-3.5 text-[#38BDF8] shrink-0 mt-0.5" />
            <div>
              <strong className="text-[#38BDF8] font-mono uppercase">
                2. Por que Comprar pelas Notícias ({latestNewsSource || "InfoMoney / B3 / Investing"}):{" "}
              </strong>
              {roboBuyDecision.newsReason}
            </div>
          </div>
        </div>
      </div>

      {/* Book-Derived Indicator Layer Bar */}
      <div className="flex flex-wrap items-center justify-between gap-1.5 px-3.5 py-1.5 bg-[#070A0F] border-b border-[#1E293B] text-[11px] font-mono">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[#94A3B8] flex items-center gap-1 mr-1">
            <BookOpen className="w-3.5 h-3.5 text-[#F59E0B]" />
            Indicadores no Gráfico Real:
          </span>

          <button
            onClick={() => setShowFibonacci(!showFibonacci)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showFibonacci
                ? "bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            FIBO 61.8% (Walker)
          </button>

          <button
            onClick={() => setShowTurtleDonchian(!showTurtleDonchian)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showTurtleDonchian
                ? "bg-[#22D3EE]/15 text-[#22D3EE] border-[#22D3EE]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            DONCHIAN 20 + 2N (Turtle)
          </button>

          <button
            onClick={() => setShowElderImpulse(!showElderImpulse)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showElderImpulse
                ? "bg-[#00E676]/15 text-[#00E676] border-[#00E676]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            ELDER IMPULSE
          </button>

          <button
            onClick={() => setShowBulkowski(!showBulkowski)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showBulkowski
                ? "bg-[#C084FC]/15 text-[#C084FC] border-[#C084FC]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            CANDLES BULKOWSKI
          </button>

          <button
            onClick={() => setShowEMA(!showEMA)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showEMA
                ? "bg-[#38BDF8]/15 text-[#38BDF8] border-[#38BDF8]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            EMA 20/50/200 (Murphy/Lemos)
          </button>

          <button
            onClick={() => setShowBollinger(!showBollinger)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showBollinger
                ? "bg-[#A855F7]/15 text-[#C084FC] border-[#A855F7]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            BOLLINGER
          </button>

          <button
            onClick={() => setShowSignalLevels(!showSignalLevels)}
            className={`px-2 py-0.5 rounded border transition-colors cursor-pointer ${
              showSignalLevels
                ? "bg-[#00E676]/15 text-[#00E676] border-[#00E676]/40 font-bold"
                : "bg-[#0D121B] text-[#64748B] border-[#1E293B]"
            }`}
          >
            ZONA DE COMPRA & ALVOS
          </button>
        </div>

        <button
          onClick={() =>
            setSubIndicator((prev) =>
              prev === "RSI_MACD"
                ? "ELDER_FORCE"
                : prev === "ELDER_FORCE"
                  ? "OBV_MURPHY"
                  : "RSI_MACD"
            )
          }
          className="px-2 py-0.5 rounded border bg-[#131B29] text-[#38BDF8] border-[#38BDF8]/40 hover:bg-[#38BDF8]/20 cursor-pointer font-bold"
        >
          OSCILADOR:{" "}
          {subIndicator === "RSI_MACD"
            ? "RSI(14) + MACD"
            : subIndicator === "ELDER_FORCE"
              ? "FORCE INDEX (Elder)"
              : "OBV VOLUME (Murphy/Lemos)"}
        </button>
      </div>

      {/* Live OHLC + Technical Indicator Telemetry Strip */}
      {inspectedCandle && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-1.5 bg-[#0A0E16] border-b border-[#1E293B] text-[11px] font-mono tabular-nums">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[#38BDF8] flex items-center gap-1 font-bold">
              <Crosshair className="w-3 h-3" />
              {inspectedCandle.label}
            </span>
            <span>
              <span className="text-[#64748B]">ABR: </span>
              <span className="text-[#F8FAFC]">
                {formatPrice(inspectedCandle.open)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">MÁX: </span>
              <span className="text-[#00E676]">
                {formatPrice(inspectedCandle.high)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">MÍN: </span>
              <span className="text-[#FF2E54]">
                {formatPrice(inspectedCandle.low)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">FECH REAL: </span>
              <span
                className={
                  inspectedCandle.close >= inspectedCandle.open
                    ? "text-[#00E676] font-bold"
                    : "text-[#FF2E54] font-bold"
                }
              >
                {formatPrice(inspectedCandle.close)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">ATR(20) N: </span>
              <span className="text-[#22D3EE]">
                {formatPrice(inspectedCandle.atr20)}
              </span>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {fiboLevels && (
              <span className="text-[#F59E0B] font-bold">
                FIBO 61.8%: {formatPrice(fiboLevels.fib618)}
              </span>
            )}
            {fiboLevels && (
              <span className="text-[#C084FC]">
                PIVOTAL: {formatPrice(fiboLevels.livermorePivotalPoint)}
              </span>
            )}
            <span className="text-[#38BDF8]">
              RSI(14): {inspectedCandle.rsi14.toFixed(1)}
            </span>
          </div>
        </div>
      )}

      {/* Main Interactive SVG Canvas of Real Market Candlesticks */}
      <div className="relative w-full bg-[#070A0F] select-none">
        <svg
          viewBox={`0 0 ${svgWidth} ${totalHeight}`}
          className="w-full h-[430px] sm:h-[465px] block"
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id="bbFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#A855F7" stopOpacity="0.11" />
              <stop offset="50%" stopColor="#38BDF8" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#A855F7" stopOpacity="0.11" />
            </linearGradient>
            <linearGradient id="goldenZoneFill" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#F59E0B" stopOpacity="0.18" />
            </linearGradient>
            <linearGradient id="buyZoneFill" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#00E676" stopOpacity="0.08" />
              <stop offset="100%" stopColor="#00E676" stopOpacity="0.22" />
            </linearGradient>
          </defs>

          {/* Horizontal Price Grid Lines */}
          {priceGridTicks.map((tick, idx) => {
            const y = priceToY(tick);
            return (
              <g key={idx}>
                <line
                  x1={0}
                  y1={y}
                  x2={plotWidth}
                  y2={y}
                  stroke="#1E293B"
                  strokeDasharray="3 3"
                  strokeWidth="0.8"
                />
                <text
                  x={plotWidth + 6}
                  y={y + 3.5}
                  fill="#64748B"
                  fontSize="10"
                  fontFamily="monospace"
                >
                  {formatPrice(tick)}
                </text>
              </g>
            );
          })}

          {/* Vertical Time Grid Lines */}
          {visibleCandles.map((c, idx) => {
            if (idx % 12 !== 0) return null;
            const x = indexToX(idx);
            return (
              <g key={`vgrid-${idx}`}>
                <line
                  x1={x}
                  y1={0}
                  x2={x}
                  y2={totalHeight}
                  stroke="#1E293B"
                  strokeDasharray="2 4"
                  strokeWidth="0.6"
                />
                <text
                  x={x}
                  y={mainHeight - 4}
                  fill="#64748B"
                  fontSize="9.5"
                  fontFamily="monospace"
                  textAnchor="middle"
                >
                  {c.label}
                </text>
              </g>
            );
          })}

          {/* ROBÔ 1 SHADED "ZONA IDEAL DE COMPRA (TÉCNICA + NOTÍCIAS)" */}
          {showSignalLevels && (
            <g>
              <rect
                x={0}
                y={Math.min(
                  priceToY(roboBuyDecision.buyZoneMax),
                  priceToY(roboBuyDecision.buyZoneMin)
                )}
                width={plotWidth}
                height={Math.max(
                  6,
                  Math.abs(
                    priceToY(roboBuyDecision.buyZoneMin) -
                      priceToY(roboBuyDecision.buyZoneMax)
                  )
                )}
                fill="url(#buyZoneFill)"
              />
              <text
                x={plotWidth - 10}
                y={
                  Math.min(
                    priceToY(roboBuyDecision.buyZoneMax),
                    priceToY(roboBuyDecision.buyZoneMin)
                  ) - 4
                }
                fill="#00E676"
                fontSize="9"
                fontWeight="bold"
                fontFamily="monospace"
                textAnchor="end"
              >
                🎯 ZONA IDEAL DE COMPRA ROBÔ 1 ({formatPrice(roboBuyDecision.buyZoneMin)} – {formatPrice(roboBuyDecision.buyZoneMax)})
              </text>
            </g>
          )}

          {/* Kenneth Walker: Fibonacci Retracements (38.2%, 50.0%, 61.8% Golden Zone) */}
          {showFibonacci && fiboLevels && (
            <g>
              <rect
                x={0}
                y={Math.min(
                  priceToY(fiboLevels.fib500),
                  priceToY(fiboLevels.fib618)
                )}
                width={plotWidth}
                height={Math.max(
                  2,
                  Math.abs(
                    priceToY(fiboLevels.fib618) - priceToY(fiboLevels.fib500)
                  )
                )}
                fill="url(#goldenZoneFill)"
              />

              {[
                {
                  label: "FIBO 38.2%",
                  val: fiboLevels.fib382,
                  color: "#FBBF24",
                },
                {
                  label: "FIBO 50.0%",
                  val: fiboLevels.fib500,
                  color: "#F59E0B",
                },
                {
                  label: "OURO 61.8% (Walker)",
                  val: fiboLevels.fib618,
                  color: "#F59E0B",
                },
                {
                  label: "PIVOTAL (Livermore)",
                  val: fiboLevels.livermorePivotalPoint,
                  color: "#C084FC",
                },
              ].map((fib) => {
                if (
                  fib.val < chartGeom.minPrice ||
                  fib.val > chartGeom.maxPrice
                )
                  return null;
                const y = priceToY(fib.val);
                return (
                  <g key={fib.label}>
                    <line
                      x1={0}
                      y1={y}
                      x2={plotWidth}
                      y2={y}
                      stroke={fib.color}
                      strokeWidth={fib.label.includes("61.8") ? "1.4" : "0.9"}
                      strokeDasharray="4 2"
                      strokeOpacity="0.8"
                    />
                    <text
                      x={12}
                      y={y - 3}
                      fill={fib.color}
                      fontSize="8.5"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      {fib.label}: {formatPrice(fib.val)}
                    </text>
                  </g>
                );
              })}
            </g>
          )}

          {/* Curtis Faith (Way of the Turtle): Donchian Channels (20) */}
          {showTurtleDonchian && (
            <>
              <polyline
                fill="none"
                stroke="#22D3EE"
                strokeWidth="1.2"
                strokeDasharray="5 3"
                strokeOpacity="0.8"
                points={donchianHighPoints}
              />
              <polyline
                fill="none"
                stroke="#22D3EE"
                strokeWidth="1.2"
                strokeDasharray="5 3"
                strokeOpacity="0.8"
                points={donchianLowPoints}
              />
            </>
          )}

          {/* Bollinger Bands Shaded Channel */}
          {showBollinger && bbAreaPolygon && (
            <>
              <polygon points={bbAreaPolygon} fill="url(#bbFill)" />
              <polyline
                fill="none"
                stroke="#A855F7"
                strokeWidth="1"
                strokeDasharray="3 2"
                strokeOpacity="0.65"
                points={bbUpperPoints}
              />
              <polyline
                fill="none"
                stroke="#A855F7"
                strokeWidth="1"
                strokeDasharray="3 2"
                strokeOpacity="0.65"
                points={bbLowerPoints}
              />
            </>
          )}

          {/* Volume Histogram Bars */}
          {visibleCandles.map((c, idx) => {
            const x = indexToX(idx);
            const barW = Math.max(2, (plotWidth / visibleCandles.length) * 0.58);
            const volH = (c.volume / chartGeom.maxVol) * 60;
            const isBull = c.close >= c.open;
            return (
              <rect
                key={`vol-${idx}`}
                x={x - barW / 2}
                y={mainHeight - 16 - volH}
                width={barW}
                height={Math.max(1, volH)}
                fill={isBull ? "#00E676" : "#FF2E54"}
                fillOpacity="0.16"
              />
            );
          })}

          {/* EMA 20 / 50 / 200 Lines */}
          {showEMA && (
            <>
              <polyline
                fill="none"
                stroke="#C084FC"
                strokeWidth="1.3"
                strokeOpacity="0.75"
                points={ema200Points}
              />
              <polyline
                fill="none"
                stroke="#F59E0B"
                strokeWidth="1.5"
                strokeOpacity="0.9"
                points={ema50Points}
              />
              <polyline
                fill="none"
                stroke="#38BDF8"
                strokeWidth="1.8"
                points={ema20Points}
              />
            </>
          )}

          {/* Robô 1 Entry, Stop Loss & Take Profit Horizontal Lines */}
          {showSignalLevels && activeSignal && (
            <g>
              {activeSignal.takeProfit1 >= chartGeom.minPrice &&
                activeSignal.takeProfit1 <= chartGeom.maxPrice && (
                  <g>
                    <line
                      x1={0}
                      y1={priceToY(activeSignal.takeProfit1)}
                      x2={plotWidth}
                      y2={priceToY(activeSignal.takeProfit1)}
                      stroke="#00E676"
                      strokeWidth="1.3"
                      strokeDasharray="5 3"
                    />
                    <rect
                      x={plotWidth + 2}
                      y={priceToY(activeSignal.takeProfit1) - 8}
                      width={rightAxisWidth - 4}
                      height={16}
                      rx={2}
                      fill="#00E676"
                    />
                    <text
                      x={plotWidth + 5}
                      y={priceToY(activeSignal.takeProfit1) + 3.5}
                      fill="#070A0F"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      ALVO {formatPrice(activeSignal.takeProfit1)}
                    </text>
                  </g>
                )}

              {activeSignal.stopLoss >= chartGeom.minPrice &&
                activeSignal.stopLoss <= chartGeom.maxPrice && (
                  <g>
                    <line
                      x1={0}
                      y1={priceToY(activeSignal.stopLoss)}
                      x2={plotWidth}
                      y2={priceToY(activeSignal.stopLoss)}
                      stroke="#FF2E54"
                      strokeWidth="1.3"
                      strokeDasharray="4 4"
                    />
                    <rect
                      x={plotWidth + 2}
                      y={priceToY(activeSignal.stopLoss) - 8}
                      width={rightAxisWidth - 4}
                      height={16}
                      rx={2}
                      fill="#FF2E54"
                    />
                    <text
                      x={plotWidth + 5}
                      y={priceToY(activeSignal.stopLoss) + 3.5}
                      fill="#FFFFFF"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                    >
                      2N STOP {formatPrice(activeSignal.stopLoss)}
                    </text>
                  </g>
                )}
            </g>
          )}

          {/* Candlesticks */}
          {visibleCandles.map((c, idx) => {
            const x = indexToX(idx);
            const candleW = Math.max(
              2.5,
              Math.min(11, (plotWidth / visibleCandles.length) * 0.66)
            );
            const isBull = c.close >= c.open;
            let color = isBull ? "#00E676" : "#FF2E54";
            if (showElderImpulse) {
              color =
                c.elderImpulse === "GREEN"
                  ? "#00E676"
                  : c.elderImpulse === "RED"
                    ? "#FF2E54"
                    : "#38BDF8";
            }

            const highY = priceToY(c.high);
            const lowY = priceToY(c.low);
            const openY = priceToY(c.open);
            const closeY = priceToY(c.close);
            const bodyTop = Math.min(openY, closeY);
            const bodyH = Math.max(1.8, Math.abs(closeY - openY));

            const isBestBuyCandle = idx === roboBuyDecision.bestCandleIdx;

            return (
              <g key={`candle-${idx}`}>
                <line
                  x1={x}
                  y1={highY}
                  x2={x}
                  y2={lowY}
                  stroke={color}
                  strokeWidth="1.2"
                />
                <rect
                  x={x - candleW / 2}
                  y={bodyTop}
                  width={candleW}
                  height={bodyH}
                  fill={color}
                  rx="0.5"
                />

                {/* Prominent Callout on the Exact Best Moment to Buy Candle */}
                {isBestBuyCandle && (
                  <g>
                    <circle
                      cx={x}
                      cy={lowY + 4}
                      r={5}
                      fill="#00E676"
                      stroke="#070A0F"
                      strokeWidth="1.5"
                    />
                    <rect
                      x={Math.min(plotWidth - 170, Math.max(6, x - 82))}
                      y={Math.min(mainHeight - 38, lowY + 11)}
                      width={164}
                      height={22}
                      rx={4}
                      fill="#00E676"
                    />
                    <text
                      x={
                        Math.min(plotWidth - 170, Math.max(6, x - 82)) + 82
                      }
                      y={Math.min(mainHeight - 38, lowY + 11) + 14.5}
                      fill="#070A0F"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      ★ MELHOR COMPRA (TÉCNICA+NOTÍCIAS)
                    </text>
                  </g>
                )}

                {showBulkowski && c.bulkowskiPattern && !isBestBuyCandle && (
                  <g>
                    <rect
                      x={x - 62}
                      y={Math.max(8, highY - 26)}
                      width={124}
                      height={17}
                      rx={3}
                      fill="#131B29"
                      stroke="#C084FC"
                      strokeWidth="1"
                    />
                    <text
                      x={x}
                      y={Math.max(8, highY - 26) + 11.5}
                      fill="#E9D5FF"
                      fontSize="8"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {c.bulkowskiPattern.name} ({c.bulkowskiPattern.reliability}%)
                    </text>
                  </g>
                )}

                {c.signalMarker && !isBestBuyCandle && (
                  <g>
                    <rect
                      x={x - 54}
                      y={
                        c.signalMarker.type === "COMPRA"
                          ? Math.min(mainHeight - 36, lowY + 8)
                          : Math.max(6, highY - 26)
                      }
                      width={108}
                      height={18}
                      rx={3}
                      fill={
                        c.signalMarker.type === "COMPRA" ? "#00E676" : "#FF2E54"
                      }
                    />
                    <text
                      x={x}
                      y={
                        c.signalMarker.type === "COMPRA"
                          ? Math.min(mainHeight - 36, lowY + 8) + 12
                          : Math.max(6, highY - 26) + 12
                      }
                      fill={
                        c.signalMarker.type === "COMPRA" ? "#070A0F" : "#FFFFFF"
                      }
                      fontSize="8"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {c.signalMarker.label} {c.signalMarker.confidence}%
                    </text>
                  </g>
                )}
              </g>
            );
          })}

          {/* Current Live Price Horizontal Tracker Line */}
          {visibleCandles.length > 0 && (
            <g>
              <line
                x1={0}
                y1={priceToY(currentPrice)}
                x2={plotWidth}
                y2={priceToY(currentPrice)}
                stroke="#38BDF8"
                strokeWidth="1.2"
                strokeDasharray="2 2"
              />
              <rect
                x={plotWidth + 2}
                y={priceToY(currentPrice) - 9}
                width={rightAxisWidth - 4}
                height={18}
                rx={2}
                fill="#38BDF8"
              />
              <text
                x={plotWidth + 6}
                y={priceToY(currentPrice) + 3.5}
                fill="#070A0F"
                fontSize="9.5"
                fontWeight="bold"
                fontFamily="monospace"
              >
                {formatPrice(currentPrice)}
              </text>
            </g>
          )}

          {/* Divider between Main Chart and Oscillator Sub-Chart */}
          <line
            x1={0}
            y1={mainHeight}
            x2={svgWidth}
            y2={mainHeight}
            stroke="#1E293B"
            strokeWidth="1.5"
          />

          <text
            x={10}
            y={mainHeight + 13}
            fill="#94A3B8"
            fontSize="9.5"
            fontFamily="monospace"
            fontWeight="bold"
          >
            {subIndicator === "RSI_MACD"
              ? "OSCILADORES EM TEMPO REAL (Elder Triple Screen 2ª Tela): RSI(14) + MACD(12,26,9)"
              : subIndicator === "ELDER_FORCE"
                ? "ÍNDICE DE FORÇA — FORCE INDEX(13) [Dr. Alexander Elder - Volume × ΔPreço]"
                : "SALDO DE VOLUME — OBV [John Murphy & Flavio Lemos - Volume Confirma Tendência]"}
          </text>

          {subIndicator === "RSI_MACD" && (
            <>
              <line
                x1={0}
                y1={rsiToY(70)}
                x2={plotWidth}
                y2={rsiToY(70)}
                stroke="#FF2E54"
                strokeOpacity="0.4"
                strokeDasharray="3 3"
                strokeWidth="0.8"
              />
              <line
                x1={0}
                y1={rsiToY(30)}
                x2={plotWidth}
                y2={rsiToY(30)}
                stroke="#00E676"
                strokeOpacity="0.4"
                strokeDasharray="3 3"
                strokeWidth="0.8"
              />
              {visibleCandles.map((c, idx) => {
                const x = indexToX(idx);
                const barW = Math.max(
                  2,
                  (plotWidth / visibleCandles.length) * 0.5
                );
                const zeroY = macdToY(0);
                const valY = macdToY(c.macdHist);
                const topY = Math.min(zeroY, valY);
                const h = Math.max(1, Math.abs(valY - zeroY));
                return (
                  <rect
                    key={`macd-hist-${idx}`}
                    x={x - barW / 2}
                    y={topY}
                    width={barW}
                    height={h}
                    fill={c.macdHist >= 0 ? "#00E676" : "#FF2E54"}
                    fillOpacity="0.38"
                  />
                );
              })}
              <polyline
                fill="none"
                stroke="#38BDF8"
                strokeWidth="1.6"
                points={rsiPoints}
              />
            </>
          )}

          {subIndicator === "ELDER_FORCE" && (
            <>
              <line
                x1={0}
                y1={forceToY(0)}
                x2={plotWidth}
                y2={forceToY(0)}
                stroke="#64748B"
                strokeDasharray="3 3"
                strokeWidth="0.9"
              />
              {visibleCandles.map((c, idx) => {
                const x = indexToX(idx);
                const barW = Math.max(
                  2,
                  (plotWidth / visibleCandles.length) * 0.52
                );
                const zeroY = forceToY(0);
                const valY = forceToY(c.forceIndex13);
                return (
                  <rect
                    key={`force-${idx}`}
                    x={x - barW / 2}
                    y={Math.min(zeroY, valY)}
                    width={barW}
                    height={Math.max(1.5, Math.abs(valY - zeroY))}
                    fill={c.forceIndex13 >= 0 ? "#00E676" : "#FF2E54"}
                    fillOpacity="0.45"
                  />
                );
              })}
              <polyline
                fill="none"
                stroke="#22D3EE"
                strokeWidth="1.6"
                points={forcePoints}
              />
            </>
          )}

          {subIndicator === "OBV_MURPHY" && (
            <polyline
              fill="none"
              stroke="#00E676"
              strokeWidth="1.8"
              points={obvPoints}
            />
          )}

          {hoverIndex !== null && visibleCandles[hoverIndex] && (
            <g>
              <line
                x1={indexToX(hoverIndex)}
                y1={0}
                x2={indexToX(hoverIndex)}
                y2={totalHeight}
                stroke="#94A3B8"
                strokeWidth="0.9"
                strokeDasharray="3 3"
              />
              <circle
                cx={indexToX(hoverIndex)}
                cy={priceToY(visibleCandles[hoverIndex].close)}
                r={3.5}
                fill="#38BDF8"
                stroke="#070A0F"
                strokeWidth="1.5"
              />
            </g>
          )}

          {visibleCandles.map((_, idx) => {
            const colW = plotWidth / visibleCandles.length;
            return (
              <rect
                key={`hit-${idx}`}
                x={idx * colW}
                y={0}
                width={colW}
                height={totalHeight}
                fill="transparent"
                className="cursor-crosshair"
                onMouseEnter={() => setHoverIndex(idx)}
              />
            );
          })}
        </svg>

        {/* Bottom Quick Execution Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-3.5 py-2.5 bg-[#0A0E16] border-t border-[#1E293B]">
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <span className="text-[#94A3B8] font-medium">
              Veredito Robô 1 (Técnica + Notícias):
            </span>
            <span className="font-mono font-bold px-2 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/40">
              ★ MELHOR COMPRA EM {currency}{" "}
              {formatPrice(roboBuyDecision.idealEntryPrice)} (ALVO{" "}
              {formatPrice(roboBuyDecision.takeProfit1)})
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onQuickOrder("COMPRA")}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-mono font-bold rounded bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90 transition-all cursor-pointer shadow-md shadow-[#00E676]/20"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              EXECUTAR COMPRA NO MOMENTO IDEAL ({symbol.split(".")[0]})
            </button>
            <button
              onClick={() => onQuickOrder("VENDA")}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-[#FF2E54] text-white hover:bg-[#FF2E54]/90 transition-all cursor-pointer"
            >
              <TrendingDown className="w-3.5 h-3.5" />
              VENDER {symbol.split(".")[0]}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
