"use client";

import React, { useState } from "react";
import {
  BrainCircuit,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  Sliders,
  Zap,
  ShieldCheck,
  RefreshCw,
} from "lucide-react";

export interface LearningLogItem {
  id: number;
  epochNumber: number;
  dayLabel: string;
  winRate: number;
  profitFactor: number;
  sharpeRatio: number;
  signalsEvaluated: number;
  weightRsi: number;
  weightMacd: number;
  weightEma: number;
  weightBollinger: number;
  weightNewsBr: number;
  weightNewsGlobal: number;
  adaptationSummary: string;
  triggerType: string;
  createdAt: string;
}

interface Robo1LearningLabProps {
  logs: LearningLogItem[];
  onTrainCycle: (focusArea: string) => Promise<void>;
  isTraining: boolean;
}

export default function Robo1LearningLab({
  logs,
  onTrainCycle,
  isTraining,
}: Robo1LearningLabProps) {
  const [selectedFocus, setSelectedFocus] = useState<string>(
    "SINERGIA_TECNICA_NOTICIAS"
  );

  const latest = logs.length > 0 ? logs[logs.length - 1] : null;
  const first = logs.length > 0 ? logs[0] : null;
  const gainSinceDay1 =
    latest && first ? (latest.winRate - first.winRate).toFixed(1) : "27.0";

  // SVG accuracy curve geometry
  const svgW = 540;
  const svgH = 155;
  const padX = 36;
  const padY = 20;

  const pointsStr = logs
    .map((log, idx) => {
      const x =
        logs.length === 1
          ? svgW / 2
          : padX + (idx / (logs.length - 1)) * (svgW - padX * 2);
      const minW = 50;
      const maxW = 98;
      const ratio = Math.min(1, Math.max(0, (log.winRate - minW) / (maxW - minW)));
      const y = svgH - padY - ratio * (svgH - padY * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  const areaPointsStr =
    logs.length > 0
      ? `${padX},${svgH - padY} ${pointsStr} ${svgW - padX},${svgH - padY}`
      : "";

  const weightItems = latest
    ? [
        {
          label: "Tendência EMA 20/50/200",
          val: Math.round(latest.weightEma * 100),
          color: "#38BDF8",
        },
        {
          label: "Momentum MACD (12,26,9)",
          val: Math.round(latest.weightMacd * 100),
          color: "#00E676",
        },
        {
          label: "NLP Notícias Brasil (B3/BCB)",
          val: Math.round(latest.weightNewsBr * 100),
          color: "#F59E0B",
        },
        {
          label: "NLP Notícias Mundo (Fed/Global)",
          val: Math.round(latest.weightNewsGlobal * 100),
          color: "#A855F7",
        },
        {
          label: "Força Relativa RSI (14)",
          val: Math.round(latest.weightRsi * 100),
          color: "#22D3EE",
        },
        {
          label: "Volatilidade Bollinger / ATR",
          val: Math.round(latest.weightBollinger * 100),
          color: "#F43F5E",
        },
      ]
    : [];

  return (
    <div className="bg-[#0D121B] border border-[#1E293B] rounded-md p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1E293B] pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-md bg-[#38BDF8]/15 border border-[#38BDF8]/40 flex items-center justify-center text-[#38BDF8]">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold tracking-wide uppercase text-[#F8FAFC]">
                ROBÔ 1 — MOTOR DE APRENDIZADO CONTÍNUO (DIA-A-DIA)
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30 font-bold">
                CICLO #{latest?.epochNumber || 30} ATIVO
              </span>
            </div>
            <p className="text-xs text-[#94A3B8]">
              Rede neural adaptativa que cruza indicadores gráficos com notícias do Brasil e Mundo, recalibrando pesos a cada sessão.
            </p>
          </div>
        </div>

        {/* Interactive Training Trigger Controls */}
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedFocus}
            onChange={(e) => setSelectedFocus(e.target.value)}
            className="bg-[#070A0F] text-[#F8FAFC] text-xs font-mono px-2.5 py-1.5 rounded border border-[#1E293B] focus:outline-none focus:border-[#38BDF8]"
          >
            <option value="SINERGIA_TECNICA_NOTICIAS">
              Foco: Sinergia Gráfica + Notícias
            </option>
            <option value="MACRO_BRASIL_B3">
              Foco: Macro Brasil (B3 / COPOM / Dólar)
            </option>
            <option value="FLUXO_GLOBAL_CRIPTO">
              Foco: Liquidez Global & Cripto 24/7
            </option>
          </select>

          <button
            onClick={() => onTrainCycle(selectedFocus)}
            disabled={isTraining}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-[#38BDF8] text-[#070A0F] hover:bg-[#38BDF8]/90 transition-all disabled:opacity-50 cursor-pointer"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isTraining ? "animate-spin" : ""}`}
            />
            {isTraining
              ? "TREINANDO REDE..."
              : "AVANÇAR CICLO DE APRENDIZADO (+1 DIA)"}
          </button>
        </div>
      </div>

      {/* KPI Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-[#070A0F] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] text-[#94A3B8] uppercase font-mono">
            Assertividade Atual (Win Rate)
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono tabular-nums">
            <span className="text-xl font-bold text-[#00E676]">
              {latest ? latest.winRate.toFixed(1) : "85.4"}%
            </span>
            <span className="text-[11px] text-[#00E676]">
              +{gainSinceDay1}% vs Dia 1
            </span>
          </div>
        </div>

        <div className="bg-[#070A0F] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] text-[#94A3B8] uppercase font-mono">
            Fator de Lucro (Profit Factor)
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono tabular-nums">
            <span className="text-xl font-bold text-[#38BDF8]">
              {latest ? latest.profitFactor.toFixed(2) : "3.18"}x
            </span>
            <span className="text-[11px] text-[#94A3B8]">Institucional</span>
          </div>
        </div>

        <div className="bg-[#070A0F] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] text-[#94A3B8] uppercase font-mono">
            Índice Sharpe Neural
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono tabular-nums">
            <span className="text-xl font-bold text-[#F8FAFC]">
              {latest ? latest.sharpeRatio.toFixed(2) : "3.04"}
            </span>
            <span className="text-[11px] text-[#00E676]">Baixo Drawdown</span>
          </div>
        </div>

        <div className="bg-[#070A0F] border border-[#1E293B] rounded p-3">
          <div className="text-[11px] text-[#94A3B8] uppercase font-mono">
            Padrões & Sinais Auditados
          </div>
          <div className="mt-1 flex items-baseline gap-2 font-mono tabular-nums">
            <span className="text-xl font-bold text-[#F59E0B]">
              {latest
                ? latest.signalsEvaluated.toLocaleString("pt-BR")
                : "1.048"}
            </span>
            <span className="text-[11px] text-[#94A3B8]">24/7 Contínuo</span>
          </div>
        </div>
      </div>

      {/* Middle Grid: Accuracy Progression Chart + Dynamic Neural Weights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Accuracy Progression SVG Chart */}
        <div className="lg:col-span-7 bg-[#070A0F] border border-[#1E293B] rounded p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono font-bold text-[#E2E8F0] flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-[#00E676]" />
              CURVA DE EVOLUÇÃO DE ASSERTIVIDADE (DIA 1 → HOJE)
            </span>
            <span className="text-[11px] font-mono text-[#38BDF8]">
              Aprendizado por Reforço Bayesiano
            </span>
          </div>

          <svg viewBox={`0 0 ${svgW} ${svgH}`} className="w-full h-36 block">
            <defs>
              <linearGradient id="learnGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00E676" stopOpacity="0.32" />
                <stop offset="100%" stopColor="#38BDF8" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal reference lines */}
            {[60, 75, 90].map((val) => {
              const ratio = (val - 50) / (98 - 50);
              const y = svgH - padY - ratio * (svgH - padY * 2);
              return (
                <g key={val}>
                  <line
                    x1={padX}
                    y1={y}
                    x2={svgW - padX}
                    y2={y}
                    stroke="#1E293B"
                    strokeDasharray="3 3"
                    strokeWidth="0.8"
                  />
                  <text
                    x={6}
                    y={y + 3}
                    fill="#64748B"
                    fontSize="9"
                    fontFamily="monospace"
                  >
                    {val}%
                  </text>
                </g>
              );
            })}

            {areaPointsStr && (
              <polygon points={areaPointsStr} fill="url(#learnGrad)" />
            )}

            {pointsStr && (
              <polyline
                fill="none"
                stroke="#00E676"
                strokeWidth="2.2"
                points={pointsStr}
              />
            )}

            {logs.map((log, idx) => {
              const x =
                logs.length === 1
                  ? svgW / 2
                  : padX + (idx / (logs.length - 1)) * (svgW - padX * 2);
              const ratio = Math.min(
                1,
                Math.max(0, (log.winRate - 50) / (98 - 50))
              );
              const y = svgH - padY - ratio * (svgH - padY * 2);
              return (
                <g key={log.id}>
                  <circle
                    cx={x}
                    cy={y}
                    r={3.5}
                    fill="#070A0F"
                    stroke="#00E676"
                    strokeWidth="2"
                  />
                  <text
                    x={x}
                    y={y - 7}
                    fill="#F8FAFC"
                    fontSize="8.5"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {log.winRate.toFixed(1)}%
                  </text>
                  <text
                    x={x}
                    y={svgH - 4}
                    fill="#94A3B8"
                    fontSize="8.5"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    #{log.epochNumber}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Dynamic Neural Weights Bars */}
        <div className="lg:col-span-5 bg-[#070A0F] border border-[#1E293B] rounded p-3 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold text-[#E2E8F0] flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-[#38BDF8]" />
              PESOS DE DECISÃO DO ROBÔ 1
            </span>
            <span className="text-[10px] font-mono text-[#94A3B8]">
              AUTO-CALIBRADO
            </span>
          </div>

          <div className="space-y-2">
            {weightItems.map((item) => (
              <div key={item.label} className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-[#CBD5E1]">{item.label}</span>
                  <span className="font-bold text-[#F8FAFC]">{item.val}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#131B29] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, item.val * 2.8)}%`,
                      backgroundColor: item.color,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Latest Daily Adaptation Log Entries */}
      <div className="space-y-2">
        <div className="text-xs font-mono font-bold text-[#94A3B8] uppercase">
          Diário de Evolução Neural (O que o Robô 1 aprendeu nos últimos ciclos):
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
          {[...logs]
            .reverse()
            .slice(0, 3)
            .map((log) => (
              <div
                key={log.id}
                className="bg-[#131B29]/70 border border-[#1E293B] rounded p-2.5 flex flex-col justify-between gap-1.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-[#38BDF8]">
                    {log.dayLabel}
                  </span>
                  <span className="text-[11px] font-mono font-bold text-[#00E676]">
                    Acerto: {log.winRate.toFixed(1)}%
                  </span>
                </div>
                <p className="text-xs text-[#CBD5E1] leading-relaxed">
                  {log.adaptationSummary}
                </p>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
