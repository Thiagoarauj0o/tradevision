"use client";

import React, { useState, useEffect, useCallback, useMemo } from "react";
import QuantumChartCanvas from "@/components/QuantumChartCanvas";
import MarketForecastTab from "@/components/MarketForecastTab";
import BooksAndPortalsHub, {
  type KnowledgeBookItem,
  type PortalFeedItem,
} from "@/components/BooksAndPortalsHub";
import Robo1LearningLab, {
  type LearningLogItem,
} from "@/components/Robo1LearningLab";
import NewsSentimentFeed, {
  type NewsEventItem,
} from "@/components/NewsSentimentFeed";
import type {
  CandlePoint,
  FibonacciSwingLevels,
  SuperOpportunityItem,
} from "@/lib/market-engine";
import {
  Activity,
  Bot,
  BrainCircuit,
  CheckCircle2,
  Clock,
  Compass,
  Flame,
  LineChart,
  Newspaper,
  Play,
  Pause,
  Radar,
  Target,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  BookOpen,
  ExternalLink,
} from "lucide-react";

interface AssetItem {
  id: number;
  symbol: string;
  name: string;
  category: string;
  currency: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: string;
  volatility: number;
  rsi14: number;
  macdHist: number;
  emaTrend: string;
  aiBias: string;
  aiConfidence: number;
}

interface TradingSignalItem {
  id: number;
  assetSymbol: string;
  assetName: string;
  marketRegion: string;
  direction: string;
  timeframe: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskReward: string;
  confidenceScore: number;
  technicalConfluence: string;
  newsCatalyst: string;
  roboLearningNote: string;
  status: string;
  pnlPercent: number;
  createdAt: string;
}

interface UserTradeItem {
  id: number;
  assetSymbol: string;
  side: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  quantity: number;
  status: string;
  pnlPercent: number;
  signalId?: number | null;
  source: string;
  createdAt: string;
}

export default function QuantumTradingTerminalPage() {
  const [assets, setAssets] = useState<AssetItem[]>([]);
  const [signals, setSignals] = useState<TradingSignalItem[]>([]);
  const [news, setNews] = useState<NewsEventItem[]>([]);
  const [learningLogs, setLearningLogs] = useState<LearningLogItem[]>([]);
  const [knowledgeBooks, setKnowledgeBooks] = useState<KnowledgeBookItem[]>([]);
  const [portalFeeds, setPortalFeeds] = useState<PortalFeedItem[]>([]);
  const [superOpportunities, setSuperOpportunities] = useState<
    SuperOpportunityItem[]
  >([]);
  const [userTrades, setUserTrades] = useState<UserTradeItem[]>([]);
  const [candles, setCandles] = useState<CandlePoint[]>([]);
  const [fiboLevels, setFiboLevels] = useState<FibonacciSwingLevels | null>(
    null
  );

  const [activeSymbol, setActiveSymbol] = useState<string>("IBOV");
  const [timeframe, setTimeframe] = useState<string>("15m");
  const [watchlistFilter, setWatchlistFilter] = useState<string>("TODOS");
  const [signalFilter, setSignalFilter] = useState<
    "TODOS" | "COMPRA" | "VENDA" | "BRASIL"
  >("TODOS");

  // OPÇÃO A = ÁREA EXCLUSIVA SOMENTE PARA PREVISÃO (1H & PRÓXIMO PREGÃO 20H)
  // OPÇÃO B = GRÁFICO DO MOMENTO REAL & MELHOR MOMENTO DE COMPRA (TÉCNICA + NOTÍCIAS)
  // OPÇÃO C = 7 LIVROS & 3 SITES OFICIAIS
  // OPÇÃO D = ROBÔ 1 (DIA-A-DIA)
  // OPÇÃO E = NOTÍCIAS
  // OPÇÃO F = ORDENS
  const [activeNavSection, setActiveNavSection] = useState<
    | "OPCAO_A_PREVISAO"
    | "OPCAO_B_TERMINAL"
    | "OPCAO_C_LIVROS_SITES"
    | "OPCAO_D_ROBO1_IA"
    | "OPCAO_E_NOTICIAS"
    | "OPCAO_F_OPERACOES"
  >("OPCAO_B_TERMINAL");

  const [isStreamLive, setIsStreamLive] = useState<boolean>(true);
  const [tickCounter, setTickCounter] = useState<number>(1842);
  const [currentTimeStr, setCurrentTimeStr] = useState<string>("24/7 ONLINE");
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [isTrainingBook, setIsTrainingBook] = useState<boolean>(false);
  const [isSyncingPortals, setIsSyncingPortals] = useState<boolean>(false);
  const [isSubmittingNews, setIsSubmittingNews] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 4500);
  };

  const fetchTerminalData = useCallback(async (sym: string, tf: string) => {
    try {
      const res = await fetch(
        `/api/terminal?symbol=${encodeURIComponent(sym)}&timeframe=${encodeURIComponent(tf)}`,
        { cache: "no-store" }
      );
      if (!res.ok) return;
      const data = await res.json();
      setAssets(data.assets || []);
      setSignals(data.signals || []);
      setNews(data.news || []);
      setLearningLogs(data.learningLogs || []);
      setKnowledgeBooks(data.knowledgeBooks || []);
      setPortalFeeds(data.portalFeeds || []);
      setSuperOpportunities(data.superOpportunities || []);
      setUserTrades(data.userTrades || []);
      setCandles(data.candles || []);
      setFiboLevels(data.fiboLevels || null);
    } catch (err) {
      console.error("Erro ao sincronizar terminal:", err);
    }
  }, []);

  useEffect(() => {
    fetchTerminalData(activeSymbol, timeframe);
  }, [activeSymbol, timeframe, fetchTerminalData]);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }) + " BRT"
      );
    };
    updateClock();
    const clockTimer = setInterval(updateClock, 1000);
    return () => clearInterval(clockTimer);
  }, []);

  // Poll real market data from backend every 10 seconds + ultra-subtle real-time orderbook pulse
  useEffect(() => {
    if (!isStreamLive) return;

    const syncInterval = setInterval(() => {
      setTickCounter((c) => c + 1);
      fetchTerminalData(activeSymbol, timeframe);
    }, 10000);

    return () => clearInterval(syncInterval);
  }, [isStreamLive, activeSymbol, timeframe, fetchTerminalData]);

  const currentAsset = useMemo(() => {
    return (
      assets.find((a) => a.symbol === activeSymbol) ||
      assets[0] || {
        id: 1,
        symbol: "IBOV",
        name: "Índice Bovespa (Carteira B3 Oficial)",
        category: "BRASIL_B3",
        currency: "PTS",
        price: 183477,
        change24h: -0.95,
        high24h: 184207,
        low24h: 182151,
        volume24h: "R$ 24,6B",
        volatility: 1.12,
        rsi14: 54.8,
        macdHist: 145,
        emaTrend: "ALTA",
        aiBias: "COMPRA FORTE",
        aiConfidence: 95,
      }
    );
  }, [assets, activeSymbol]);

  const activeSignalForChart = useMemo(() => {
    return (
      signals.find(
        (s) => s.assetSymbol === activeSymbol && s.status === "ATIVO"
      ) || null
    );
  }, [signals, activeSymbol]);

  const matchingNewsForChart = useMemo(() => {
    const tickerKey = activeSymbol.split(".")[0];
    return (
      news.find((n) => n.relatedAssets.includes(tickerKey)) ||
      news[0] || {
        title:
          "[InfoMoney / B3 / Investing.com] Fluxo comprador institucional sustenta suporte de Fibonacci no Ibovespa (183.477 pts) e líderes da carteira.",
        source: "InfoMoney / B3 Oficial / Investing.com",
        sentimentScore: 91,
      }
    );
  }, [news, activeSymbol]);

  const filteredWatchlist = useMemo(() => {
    if (watchlistFilter === "TODOS") return assets;
    return assets.filter((a) => a.category === watchlistFilter);
  }, [assets, watchlistFilter]);

  const filteredSignals = useMemo(() => {
    return signals.filter((s) => {
      if (signalFilter === "COMPRA") return s.direction.includes("COMPRA");
      if (signalFilter === "VENDA") return s.direction.includes("VENDA");
      if (signalFilter === "BRASIL") return s.marketRegion === "BRASIL";
      return true;
    });
  }, [signals, signalFilter]);

  const latestLearning = useMemo(() => {
    return learningLogs.length > 0
      ? learningLogs[learningLogs.length - 1]
      : null;
  }, [learningLogs]);

  const handleScanWithRobo1 = async (targetSym?: string) => {
    const symToScan = targetSym || activeSymbol;
    setIsScanning(true);
    try {
      const res = await fetch("/api/robo1", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "SCAN_OPPORTUNITIES",
          symbol: symToScan,
          timeframe,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(symToScan, timeframe);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleTrainDailyCycle = async (focusArea: string) => {
    setIsTraining(true);
    try {
      const res = await fetch("/api/robo1", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "TRAIN_DAILY_CYCLE",
          focusArea,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsTraining(false);
    }
  };

  const handleTrainBookDoctrine = async (bookCode: string) => {
    setIsTrainingBook(true);
    try {
      const res = await fetch("/api/robo1", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "TRAIN_BOOK_DOCTRINE",
          bookCode,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsTrainingBook(false);
    }
  };

  const handleSyncPortals = async (portalCode: string) => {
    setIsSyncingPortals(true);
    try {
      const res = await fetch("/api/robo1", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "SYNC_PORTAL_FEEDS",
          portalCode,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSyncingPortals(false);
    }
  };

  const handleIngestNews = async (payload: {
    title: string;
    region: string;
    source: string;
    relatedAssets: string;
  }) => {
    setIsSubmittingNews(true);
    try {
      const res = await fetch("/api/robo1", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "INGEST_NEWS",
          ...payload,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmittingNews(false);
    }
  };

  const handleExecuteSignalTrade = async (sig: TradingSignalItem) => {
    try {
      const side = sig.direction.includes("COMPRA") ? "COMPRA" : "VENDA";
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "OPEN_TRADE",
          assetSymbol: sig.assetSymbol,
          side,
          entryPrice: sig.entryPrice,
          stopLoss: sig.stopLoss,
          takeProfit: sig.takeProfit1,
          quantity: sig.assetSymbol.includes("BTC") ? 0.15 : 100,
          signalId: sig.id,
          source: "ROBO_1",
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        setActiveSymbol(sig.assetSymbol);
        await fetchTerminalData(sig.assetSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleExecuteSuperOpportunity = async (opp: SuperOpportunityItem) => {
    try {
      const side = opp.action.includes("COMPRA") ? "COMPRA" : "VENDA";
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "OPEN_TRADE",
          assetSymbol: opp.symbol,
          side,
          entryPrice: opp.entryZone,
          stopLoss: opp.turtleStop2N,
          takeProfit: opp.targetFib1618,
          quantity: opp.symbol.includes("BTC") ? 0.15 : 100,
          source: "MATRIZ_7LIVROS_PORTAIS",
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        setActiveSymbol(opp.symbol);
        await fetchTerminalData(opp.symbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleExecuteForecastTrade = async (payload: {
    symbol: string;
    side: "COMPRA" | "VENDA";
    entryPrice: number;
    stopLoss: number;
    takeProfit: number;
  }) => {
    try {
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "OPEN_TRADE",
          assetSymbol: payload.symbol,
          side: payload.side,
          entryPrice: payload.entryPrice,
          stopLoss: payload.stopLoss,
          takeProfit: payload.takeProfit,
          quantity: payload.symbol.includes("BTC") ? 0.15 : 100,
          source: "PREVISAO_IA_1H_20H",
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(payload.symbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleQuickOrderFromChart = async (side: "COMPRA" | "VENDA") => {
    const price = currentAsset.price;
    const isBuy = side === "COMPRA";
    const sl = Number((isBuy ? price * 0.988 : price * 1.012).toFixed(2));
    const tp = Number((isBuy ? price * 1.024 : price * 0.976).toFixed(2));

    try {
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "OPEN_TRADE",
          assetSymbol: currentAsset.symbol,
          side,
          entryPrice: price,
          stopLoss: sl,
          takeProfit: tp,
          quantity: currentAsset.symbol.includes("BTC") ? 0.1 : 100,
          source: "GRAFICO_MOMENTO_REAL",
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCloseTradeWithFeedback = async (
    tradeId: number,
    outcomePnl: number
  ) => {
    try {
      const res = await fetch("/api/trades", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "CLOSE_TRADE",
          tradeId,
          outcomePnl,
        }),
      });
      const data = await res.json();
      if (data.status === "ok") {
        showToast(data.message);
        await fetchTerminalData(activeSymbol, timeframe);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const formatNum = (val: number, sym?: string) => {
    if (val >= 10000 || sym === "IBOV" || sym === "WINJ26")
      return val.toLocaleString("pt-BR", { maximumFractionDigits: 0 });
    if (val < 10)
      return val.toLocaleString("pt-BR", {
        minimumFractionDigits: 3,
        maximumFractionDigits: 4,
      });
    return val.toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  };

  return (
    <div className="min-h-screen bg-[#070A0F] text-[#F8FAFC] flex flex-col">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 max-w-md bg-[#131B29] border-2 border-[#00E676] text-[#F8FAFC] px-4 py-3 rounded-md shadow-2xl flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-[#00E676] shrink-0 mt-0.5" />
          <div className="text-xs font-mono leading-relaxed">{toastMessage}</div>
        </div>
      )}

      {/* TOP 24/7 COMMAND BAR */}
      <header className="sticky top-0 z-40 min-h-14 py-2 bg-[#0A0E16]/95 backdrop-blur-md border-b border-[#1E293B] px-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[#00E676]/15 border border-[#00E676]/40 flex items-center justify-center text-[#00E676]">
              <Radar className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-mono font-bold text-sm tracking-wider text-[#F8FAFC]">
                  QUANTUM<span className="text-[#38BDF8]">.AI</span>
                </span>
                <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30">
                  DADOS REAIS B3 / YAHOO
                </span>
              </div>
              <div className="text-[10px] text-[#94A3B8] hidden sm:block">
                Gráfico Real 24/7 • Opção A: Previsão Exclusiva • InfoMoney / B3 / Investing.com
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Pills */}
        <nav className="flex flex-wrap items-center gap-1.5 bg-[#070A0F] p-1 rounded border border-[#1E293B]">
          {/* OPÇÃO B: GRÁFICO DO MOMENTO REAL & MELHOR COMPRA */}
          <button
            onClick={() => setActiveNavSection("OPCAO_B_TERMINAL")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded transition-all cursor-pointer ${
              activeNavSection === "OPCAO_B_TERMINAL"
                ? "bg-[#00E676] text-[#070A0F] font-bold shadow-md shadow-[#00E676]/20"
                : "text-[#00E676] bg-[#00E676]/10 border border-[#00E676]/30 hover:bg-[#00E676]/20 font-bold"
            }`}
          >
            <LineChart className="w-3.5 h-3.5" />
            <span>GRÁFICO REAL & MELHOR COMPRA (ROBÔ 1)</span>
          </button>

          {/* OPÇÃO A: ÁREA EXCLUSIVA SOMENTE PARA PREVISÃO */}
          <button
            onClick={() => setActiveNavSection("OPCAO_A_PREVISAO")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded transition-all cursor-pointer border ${
              activeNavSection === "OPCAO_A_PREVISAO"
                ? "bg-[#F59E0B] text-[#070A0F] border-[#F59E0B] font-bold shadow-lg shadow-[#F59E0B]/20"
                : "bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/40 hover:bg-[#F59E0B]/25 font-bold"
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>OPÇÃO A: PREVISÃO EXCLUSIVA (1H & PRÓX. PREGÃO 20H)</span>
          </button>

          {/* OPÇÃO C: 7 LIVROS & ENDEREÇOS DOS 3 SITES */}
          <button
            onClick={() => setActiveNavSection("OPCAO_C_LIVROS_SITES")}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer ${
              activeNavSection === "OPCAO_C_LIVROS_SITES"
                ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>7 Livros & 3 Sites</span>
          </button>

          {/* OPÇÃO D: ROBÔ 1 DIA-A-DIA */}
          <button
            onClick={() => setActiveNavSection("OPCAO_D_ROBO1_IA")}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer ${
              activeNavSection === "OPCAO_D_ROBO1_IA"
                ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <BrainCircuit className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Robô 1 (Dia-a-Dia)</span>
          </button>

          {/* OPÇÃO E: NOTÍCIAS */}
          <button
            onClick={() => setActiveNavSection("OPCAO_E_NOTICIAS")}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer ${
              activeNavSection === "OPCAO_E_NOTICIAS"
                ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <Newspaper className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">Notícias</span>
          </button>

          {/* OPÇÃO F: ORDENS */}
          <button
            onClick={() => setActiveNavSection("OPCAO_F_OPERACOES")}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono rounded transition-colors cursor-pointer ${
              activeNavSection === "OPCAO_F_OPERACOES"
                ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                : "text-[#94A3B8] hover:text-[#F8FAFC]"
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">
              Ordens ({userTrades.filter((t) => t.status === "ABERTA").length})
            </span>
          </button>
        </nav>

        {/* Right Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (typeof window !== "undefined") {
                const url = window.location.href;
                if (navigator.clipboard) {
                  navigator.clipboard.writeText(url);
                }
                showToast(
                  `Link do site copiado: ${url} — Cole em qualquer navegador para acompanhar 24h!`
                );
                window.open(url, "_blank", "noopener,noreferrer");
              }
            }}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono font-bold rounded bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/40 hover:bg-[#38BDF8] hover:text-[#070A0F] transition-colors cursor-pointer"
            title="Copiar endereço do site e abrir em uma nova guia do navegador"
          >
            <ExternalLink className="w-3 h-3" />
            <span className="hidden sm:inline">ABRIR NO NAVEGADOR</span>
          </button>

          <button
            onClick={() => setIsStreamLive(!isStreamLive)}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono rounded border cursor-pointer ${
              isStreamLive
                ? "bg-[#00E676]/15 text-[#00E676] border-[#00E676]/40"
                : "bg-[#FF2E54]/15 text-[#FF2E54] border-[#FF2E54]/40"
            }`}
          >
            {isStreamLive ? (
              <Pause className="w-3 h-3" />
            ) : (
              <Play className="w-3 h-3" />
            )}
            <span className="hidden sm:inline">
              {isStreamLive ? `SYNC REAL #${tickCounter}` : "PAUSADO"}
            </span>
          </button>

          <div className="hidden xl:flex items-center gap-1.5 text-xs font-mono text-[#94A3B8] bg-[#070A0F] px-2.5 py-1 rounded border border-[#1E293B]">
            <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>{currentTimeStr}</span>
          </div>
        </div>
      </header>

      {/* OFFICIAL MARKET PORTALS URL BAR */}
      <div className="bg-[#0A0E16] border-b border-[#1E293B] px-3.5 py-1.5 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[#94A3B8] font-bold">
            🌐 ENDEREÇOS DOS SITES INTEGRADOS AO ROBÔ 1:
          </span>
          <a
            href="https://www.infomoney.com.br/cotacoes/b3/indice/ibovespa/"
            target="_blank"
            rel="noopener noreferrer"
            className="px-2 py-0.5 rounded bg-[#131B29] text-[#38BDF8] border border-[#38BDF8]/30 hover:border-[#38BDF8] flex items-center gap-1"
          >
            <span>https://www.infomoney.com.br/cotacoes/b3/indice/ibovespa/</span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="https://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/ibovespa.htm"
            target="_blank"
            rel="noopener noreferrer"
            className="px-2 py-0.5 rounded bg-[#131B29] text-[#00E676] border border-[#00E676]/30 hover:border-[#00E676] flex items-center gap-1"
          >
            <span>
              https://www.b3.com.br/pt_br/market-data-e-indices/indices/indices-amplos/ibovespa.htm
            </span>
            <ExternalLink className="w-3 h-3" />
          </a>
          <a
            href="https://br.investing.com/indices/bovespa"
            target="_blank"
            rel="noopener noreferrer"
            className="px-2 py-0.5 rounded bg-[#131B29] text-[#F59E0B] border border-[#F59E0B]/30 hover:border-[#F59E0B] flex items-center gap-1"
          >
            <span>https://br.investing.com/indices/bovespa</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <span className="text-[#00E676] font-bold hidden lg:inline">
          ASSERTIVIDADE ROBÔ 1:{" "}
          {latestLearning ? latestLearning.winRate.toFixed(1) : "92.4"}% (CICLO #
          {latestLearning?.epochNumber || 35})
        </span>
      </div>

      {/* LIVE 24/7 REAL-TIME MARKET TICKER TAPE */}
      <div className="bg-[#070A0F] border-b border-[#1E293B] px-3 py-1.5 flex items-center gap-2 overflow-x-auto">
        <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded bg-[#00E676]/15 text-[#00E676] border border-[#00E676]/30 shrink-0">
          COTAÇÕES REAIS 24/7
        </span>
        <div className="flex items-center gap-2">
          {assets.map((asset) => {
            const isUp = asset.change24h >= 0;
            const isSelected = asset.symbol === activeSymbol;
            return (
              <button
                key={asset.symbol}
                onClick={() => setActiveSymbol(asset.symbol)}
                className={`flex items-center gap-2 px-2.5 py-1 rounded text-xs font-mono tabular-nums transition-all shrink-0 cursor-pointer border ${
                  isSelected
                    ? "bg-[#131B29] border-[#38BDF8] text-[#F8FAFC]"
                    : "bg-[#0D121B] border-[#1E293B] text-[#CBD5E1] hover:border-[#38BDF8]/50"
                }`}
              >
                <span className="font-bold">{asset.symbol}</span>
                <span>
                  {asset.currency} {formatNum(asset.price, asset.symbol)}
                </span>
                <span
                  className={`text-[11px] font-bold ${
                    isUp ? "text-[#00E676]" : "text-[#FF2E54]"
                  }`}
                >
                  {isUp ? "+" : ""}
                  {asset.change24h.toFixed(2)}%
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* MAIN WORKSPACE CONTENT */}
      <main className="flex-1 p-3 sm:p-4 max-w-[1920px] w-full mx-auto space-y-4">
        {/* OPÇÃO A: ÁREA EXCLUSIVA SOMENTE PARA PREVISÃO (1 HORA + 20H ANTES DO PRÓXIMO PREGÃO) */}
        {activeNavSection === "OPCAO_A_PREVISAO" && (
          <MarketForecastTab
            assets={assets}
            activeSymbol={activeSymbol}
            onSelectSymbol={(sym) => setActiveSymbol(sym)}
            candles={candles}
            fiboLevels={fiboLevels}
            onExecuteForecastTrade={handleExecuteForecastTrade}
            onRecalibrateForecast={handleScanWithRobo1}
            isScanning={isScanning}
          />
        )}

        {/* OPÇÃO C: 7 LIVROS & 3 SITES OFICIAIS */}
        {activeNavSection === "OPCAO_C_LIVROS_SITES" && (
          <BooksAndPortalsHub
            books={knowledgeBooks}
            portalFeeds={portalFeeds}
            superOpportunities={superOpportunities}
            onTrainBook={handleTrainBookDoctrine}
            onSyncPortals={handleSyncPortals}
            onSelectSymbol={(sym) => {
              setActiveSymbol(sym);
              setActiveNavSection("OPCAO_B_TERMINAL");
            }}
            onExecuteOpportunity={handleExecuteSuperOpportunity}
            isTrainingBook={isTrainingBook}
            isSyncingPortals={isSyncingPortals}
          />
        )}

        {/* OPÇÃO D: ROBÔ 1 DIA-A-DIA */}
        {activeNavSection === "OPCAO_D_ROBO1_IA" && (
          <Robo1LearningLab
            logs={learningLogs}
            onTrainCycle={handleTrainDailyCycle}
            isTraining={isTraining}
          />
        )}

        {/* OPÇÃO E: NOTÍCIAS BRASIL & MUNDO */}
        {activeNavSection === "OPCAO_E_NOTICIAS" && (
          <NewsSentimentFeed
            news={news}
            onSelectSymbol={(sym) => {
              setActiveSymbol(sym);
              setActiveNavSection("OPCAO_B_TERMINAL");
            }}
            onIngestNews={handleIngestNews}
            isSubmittingNews={isSubmittingNews}
          />
        )}

        {/* OPÇÃO F: OPERAÇÕES & ORDENS */}
        {activeNavSection === "OPCAO_F_OPERACOES" && (
          <div className="bg-[#0D121B] border border-[#1E293B] rounded-md p-4 space-y-4">
            <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
              <div>
                <h2 className="text-sm font-mono font-bold uppercase text-[#F8FAFC]">
                  HISTÓRICO DE ORDENS & AUDITORIA DE SINAIS DO ROBÔ 1
                </h2>
                <p className="text-xs text-[#94A3B8]">
                  Todas as operações executadas alimentam o banco de dados PostgreSQL para recalibragem diária da assertividade.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#1E293B] text-[#94A3B8] text-[11px]">
                    <th className="py-2.5 px-3">ID</th>
                    <th className="py-2.5 px-3">ATIVO</th>
                    <th className="py-2.5 px-3">DIREÇÃO</th>
                    <th className="py-2.5 px-3">ORIGEM</th>
                    <th className="py-2.5 px-3">PREÇO ENTRADA</th>
                    <th className="py-2.5 px-3">STOP LOSS</th>
                    <th className="py-2.5 px-3">ALVO (TP)</th>
                    <th className="py-2.5 px-3">RESULTADO</th>
                    <th className="py-2.5 px-3">STATUS / FEEDBACK IA</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E293B]">
                  {userTrades.map((t) => (
                    <tr key={t.id} className="hover:bg-[#131B29]/50">
                      <td className="py-2.5 px-3 text-[#64748B]">#{t.id}</td>
                      <td className="py-2.5 px-3 font-bold text-[#F8FAFC]">
                        {t.assetSymbol}
                      </td>
                      <td className="py-2.5 px-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            t.side === "COMPRA"
                              ? "bg-[#00E676]/20 text-[#00E676]"
                              : "bg-[#FF2E54]/20 text-[#FF2E54]"
                          }`}
                        >
                          {t.side}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-[#38BDF8]">{t.source}</td>
                      <td className="py-2.5 px-3">
                        {formatNum(t.entryPrice, t.assetSymbol)}
                      </td>
                      <td className="py-2.5 px-3 text-[#FF2E54]">
                        {formatNum(t.stopLoss, t.assetSymbol)}
                      </td>
                      <td className="py-2.5 px-3 text-[#00E676]">
                        {formatNum(t.takeProfit, t.assetSymbol)}
                      </td>
                      <td
                        className={`py-2.5 px-3 font-bold ${
                          t.pnlPercent >= 0 ? "text-[#00E676]" : "text-[#FF2E54]"
                        }`}
                      >
                        {t.pnlPercent >= 0 ? "+" : ""}
                        {t.pnlPercent.toFixed(2)}%
                      </td>
                      <td className="py-2.5 px-3">
                        {t.status === "ABERTA" ? (
                          <button
                            onClick={() =>
                              handleCloseTradeWithFeedback(
                                t.id,
                                Math.max(1.5, t.pnlPercent)
                              )
                            }
                            className="px-2.5 py-1 rounded bg-[#00E676] text-[#070A0F] font-bold text-[10px] cursor-pointer"
                          >
                            ENCERRAR & ENSINAR ROBÔ 1
                          </button>
                        ) : (
                          <span className="text-[#00E676]">
                            ✓ {t.status} (PROCESSADO PELO ROBÔ 1)
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* OPÇÃO B: GRÁFICO DO MOMENTO REAL DO MERCADO + MELHOR MOMENTO PARA COMPRA (TÉCNICA + NOTÍCIAS) */}
        {activeNavSection === "OPCAO_B_TERMINAL" && (
          <>
            <div className="bg-gradient-to-r from-[#0D121B] via-[#131B29] to-[#0D121B] border border-[#1E293B] rounded-md p-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-md bg-[#00E676]/15 border border-[#00E676]/40 flex items-center justify-center text-[#00E676] shrink-0">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono font-bold uppercase text-[#00E676]">
                      GRÁFICO DO MOMENTO REAL DO MERCADO • ROBÔ 1 (TÉCNICA + NOTÍCIAS)
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30 font-bold">
                      7 LIVROS + INFOMONEY / B3 / INVESTING
                    </span>
                  </div>
                  <p className="text-xs text-[#CBD5E1] mt-0.5">
                    Cotações e candles reais sincronizados diretamente do mercado financeiro (IBOV: 183.477 pts | PETR4: R$ 47,99 | VALE3: R$ 70,77 | B3SA3: R$ 17,96 | USD/BRL: R$ 5,187 | BTC: US$ 84.863 | NVDA: US$ 225,07).
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setActiveNavSection("OPCAO_A_PREVISAO")}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-[#F59E0B] text-[#070A0F] hover:bg-[#F59E0B]/90 transition-all cursor-pointer"
                >
                  <Compass className="w-3.5 h-3.5" />
                  IR PARA OPÇÃO A: PREVISÃO EXCLUSIVA (1H & 20H)
                </button>

                <button
                  onClick={() => handleScanWithRobo1(activeSymbol)}
                  disabled={isScanning}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-bold rounded bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90 transition-all cursor-pointer"
                >
                  <Zap className="w-3.5 h-3.5" />
                  {isScanning
                    ? "ESCANEANDO..."
                    : `ESCANEAR MELHOR COMPRA (${activeSymbol})`}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-3.5 items-start">
              {/* LEFT PANEL (3 COLS): MULTI-MARKET WATCHLIST */}
              <div className="xl:col-span-3 bg-[#0D121B] border border-[#1E293B] rounded-md flex flex-col overflow-hidden">
                <div className="p-3 border-b border-[#1E293B] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-[#38BDF8]" />
                    <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-[#F8FAFC]">
                      COTAÇÕES REAIS 24/7
                    </h2>
                  </div>
                  <span className="text-[10px] font-mono text-[#00E676]">
                    TEMPO REAL
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-1 p-2 bg-[#070A0F] border-b border-[#1E293B] text-[10px] font-mono">
                  {[
                    { id: "TODOS", label: "TODOS" },
                    { id: "BRASIL_B3", label: "🇧🇷 B3" },
                    { id: "CRIPTO_24H", label: "⚡ CRIPTO" },
                    { id: "GLOBAL_US", label: "🌐 GLOBAL" },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setWatchlistFilter(cat.id)}
                      className={`py-1 rounded text-center transition-colors cursor-pointer ${
                        watchlistFilter === cat.id
                          ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                          : "bg-[#0D121B] text-[#94A3B8] hover:text-[#F8FAFC]"
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                <div className="divide-y divide-[#1E293B] max-h-[620px] overflow-y-auto">
                  {filteredWatchlist.map((asset) => {
                    const isSelected = asset.symbol === activeSymbol;
                    const isPos = asset.change24h >= 0;
                    const isBuyBias = asset.aiBias.includes("COMPRA");

                    return (
                      <div
                        key={asset.symbol}
                        onClick={() => setActiveSymbol(asset.symbol)}
                        className={`p-3 transition-colors cursor-pointer ${
                          isSelected
                            ? "bg-[#131B29] border-l-2 border-l-[#00E676]"
                            : "hover:bg-[#131B29]/50"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono text-xs font-bold text-[#F8FAFC]">
                                {asset.symbol}
                              </span>
                              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#070A0F] text-[#94A3B8] border border-[#1E293B]">
                                RSI {asset.rsi14.toFixed(0)}
                              </span>
                            </div>
                            <div className="text-[11px] text-[#94A3B8] truncate max-w-[145px]">
                              {asset.name}
                            </div>
                          </div>

                          <div className="text-right font-mono tabular-nums">
                            <div className="text-xs font-bold text-[#F8FAFC]">
                              {asset.currency}{" "}
                              {formatNum(asset.price, asset.symbol)}
                            </div>
                            <div
                              className={`text-[11px] font-semibold flex items-center justify-end gap-0.5 ${
                                isPos ? "text-[#00E676]" : "text-[#FF2E54]"
                              }`}
                            >
                              {isPos ? (
                                <ArrowUpRight className="w-3 h-3" />
                              ) : (
                                <ArrowDownRight className="w-3 h-3" />
                              )}
                              {isPos ? "+" : ""}
                              {asset.change24h.toFixed(2)}%
                            </div>
                          </div>
                        </div>

                        <div className="mt-2 flex items-center justify-between text-[10px] font-mono">
                          <span
                            className={`px-1.5 py-0.5 rounded font-bold border ${
                              isBuyBias
                                ? "bg-[#00E676]/15 text-[#00E676] border-[#00E676]/30"
                                : "bg-[#FF2E54]/15 text-[#FF2E54] border-[#FF2E54]/30"
                            }`}
                          >
                            ROBÔ 1: {asset.aiBias}
                          </span>
                          <span className="text-[#38BDF8] font-semibold">
                            {asset.aiConfidence}% Convicção
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* CENTER PANEL (5 COLS): REAL-TIME CANDLESTICK CHART + BEST MOMENT TO BUY */}
              <div className="xl:col-span-5 flex flex-col gap-3.5">
                <QuantumChartCanvas
                  symbol={currentAsset.symbol}
                  assetName={currentAsset.name}
                  currency={currentAsset.currency}
                  currentPrice={currentAsset.price}
                  change24h={currentAsset.change24h}
                  timeframe={timeframe}
                  onTimeframeChange={(tf) => setTimeframe(tf)}
                  candles={candles}
                  fiboLevels={fiboLevels}
                  activeSignal={activeSignalForChart}
                  latestNewsTitle={matchingNewsForChart.title}
                  latestNewsSource={matchingNewsForChart.source}
                  latestNewsScore={matchingNewsForChart.sentimentScore}
                  onQuickOrder={handleQuickOrderFromChart}
                  onScanWithRobo1={() =>
                    handleScanWithRobo1(currentAsset.symbol)
                  }
                  isScanning={isScanning}
                />

                <div className="bg-[#0D121B] border border-[#1E293B] rounded-md p-3.5">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 mb-2.5 border-b border-[#1E293B]">
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-[#00E676]" />
                      <h3 className="text-xs font-mono font-bold uppercase text-[#F8FAFC]">
                        POSIÇÕES EM ABERTO & FEEDBACK PARA O ROBÔ 1
                      </h3>
                    </div>
                  </div>

                  <div className="space-y-2 max-h-[210px] overflow-y-auto">
                    {userTrades.slice(0, 5).map((trade) => {
                      const isGain = trade.pnlPercent >= 0;
                      const isOpen = trade.status === "ABERTA";
                      return (
                        <div
                          key={trade.id}
                          className="flex flex-wrap items-center justify-between gap-2 bg-[#070A0F] border border-[#1E293B] rounded px-3 py-2 text-xs font-mono"
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                trade.side === "COMPRA"
                                  ? "bg-[#00E676]/20 text-[#00E676]"
                                  : "bg-[#FF2E54]/20 text-[#FF2E54]"
                              }`}
                            >
                              {trade.side}
                            </span>
                            <span className="font-bold text-[#F8FAFC]">
                              {trade.assetSymbol}
                            </span>
                            <span className="text-[#94A3B8] text-[11px]">
                              Entrada:{" "}
                              {formatNum(trade.entryPrice, trade.assetSymbol)} |
                              Alvo:{" "}
                              <strong className="text-[#00E676]">
                                {formatNum(trade.takeProfit, trade.assetSymbol)}
                              </strong>
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span
                              className={`font-bold ${
                                isGain ? "text-[#00E676]" : "text-[#FF2E54]"
                              }`}
                            >
                              {isGain ? "+" : ""}
                              {trade.pnlPercent.toFixed(2)}%
                            </span>

                            {isOpen ? (
                              <div className="flex items-center gap-1">
                                <button
                                  onClick={() =>
                                    handleCloseTradeWithFeedback(
                                      trade.id,
                                      Math.max(
                                        1.25,
                                        Math.abs(trade.pnlPercent) + 0.8
                                      )
                                    )
                                  }
                                  className="px-2 py-0.5 text-[10px] rounded bg-[#00E676]/20 text-[#00E676] border border-[#00E676]/40 hover:bg-[#00E676] hover:text-[#070A0F] font-bold transition-colors cursor-pointer"
                                >
                                  GAIN (+IA)
                                </button>
                                <button
                                  onClick={() =>
                                    handleCloseTradeWithFeedback(
                                      trade.id,
                                      -0.95
                                    )
                                  }
                                  className="px-2 py-0.5 text-[10px] rounded bg-[#FF2E54]/15 text-[#FF2E54] border border-[#FF2E54]/30 hover:bg-[#FF2E54] hover:text-white transition-colors cursor-pointer"
                                >
                                  STOP (-IA)
                                </button>
                              </div>
                            ) : (
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#131B29] text-[#38BDF8]">
                                {trade.status}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* RIGHT PANEL (4 COLS): MELHORES OPORTUNIDADES DE COMPRA E VENDA */}
              <div className="xl:col-span-4 bg-[#0D121B] border border-[#1E293B] rounded-md flex flex-col overflow-hidden">
                <div className="p-3.5 border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2 bg-[#0A0E16]">
                  <div className="flex items-center gap-2">
                    <Flame className="w-4 h-4 text-[#00E676]" />
                    <div>
                      <h2 className="text-xs font-mono font-bold uppercase tracking-wider text-[#F8FAFC]">
                        MELHORES OPORTUNIDADES (COMPRA / VENDA)
                      </h2>
                      <p className="text-[11px] text-[#94A3B8]">
                        Preços Reais + 7 Livros + InfoMoney, B3 & Investing.com
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-4 gap-1 p-2 bg-[#070A0F] border-b border-[#1E293B] text-[10px] font-mono">
                  {(
                    [
                      { id: "TODOS", label: "TODAS" },
                      { id: "COMPRA", label: "🟢 COMPRAS" },
                      { id: "VENDA", label: "🔴 VENDAS" },
                      { id: "BRASIL", label: "🇧🇷 BRASIL" },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setSignalFilter(tab.id)}
                      className={`py-1 rounded text-center transition-colors cursor-pointer ${
                        signalFilter === tab.id
                          ? "bg-[#38BDF8] text-[#070A0F] font-bold"
                          : "bg-[#0D121B] text-[#94A3B8] hover:text-[#F8FAFC]"
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <div className="p-3 space-y-3 max-h-[670px] overflow-y-auto">
                  {filteredSignals.map((sig) => {
                    const isBuy = sig.direction.includes("COMPRA");
                    return (
                      <div
                        key={sig.id}
                        className={`bg-[#070A0F] rounded-md p-3.5 border transition-all space-y-2.5 ${
                          isBuy
                            ? "border-[#00E676]/35 hover:border-[#00E676]"
                            : "border-[#FF2E54]/35 hover:border-[#FF2E54]"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span
                              className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                                isBuy
                                  ? "bg-[#00E676] text-[#070A0F]"
                                  : "bg-[#FF2E54] text-white"
                              }`}
                            >
                              {sig.direction}
                            </span>
                            <div>
                              <span className="font-mono font-bold text-sm text-[#F8FAFC]">
                                {sig.assetSymbol}
                              </span>
                              <span className="ml-1.5 text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#131B29] text-[#94A3B8]">
                                {sig.timeframe} • {sig.marketRegion}
                              </span>
                            </div>
                          </div>

                          <div className="text-right font-mono">
                            <div className="text-xs font-bold text-[#38BDF8]">
                              {sig.confidenceScore}% IA
                            </div>
                            <div className="text-[10px] text-[#94A3B8]">
                              R/R {sig.riskReward}
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-4 gap-1.5 bg-[#0D121B] p-2 rounded border border-[#1E293B] font-mono text-[11px] tabular-nums">
                          <div>
                            <div className="text-[9px] text-[#64748B] uppercase">
                              ENTRADA
                            </div>
                            <div className="font-bold text-[#F8FAFC]">
                              {formatNum(sig.entryPrice, sig.assetSymbol)}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-[#FF2E54] uppercase">
                              STOP 2N
                            </div>
                            <div className="font-bold text-[#FF2E54]">
                              {formatNum(sig.stopLoss, sig.assetSymbol)}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-[#00E676] uppercase">
                              ALVO 1
                            </div>
                            <div className="font-bold text-[#00E676]">
                              {formatNum(sig.takeProfit1, sig.assetSymbol)}
                            </div>
                          </div>
                          <div>
                            <div className="text-[9px] text-[#38BDF8] uppercase">
                              ALVO 2
                            </div>
                            <div className="font-bold text-[#38BDF8]">
                              {formatNum(sig.takeProfit2, sig.assetSymbol)}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-1.5 text-xs">
                          <div className="text-[#CBD5E1] leading-snug">
                            <strong className="text-[#38BDF8] font-mono text-[11px]">
                              [CONFLUÊNCIA TÉCNICA 7 LIVROS]:{" "}
                            </strong>
                            {sig.technicalConfluence}
                          </div>
                          <div className="text-[#CBD5E1] leading-snug">
                            <strong className="text-[#F59E0B] font-mono text-[11px]">
                              [NOTÍCIAS & PORTAIS]:{" "}
                            </strong>
                            {sig.newsCatalyst}
                          </div>
                          <div className="text-[11px] font-mono text-[#94A3B8] bg-[#131B29] px-2 py-1 rounded border border-[#1E293B]">
                            🧠 {sig.roboLearningNote}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 pt-1">
                          <button
                            onClick={() => {
                              setActiveSymbol(sig.assetSymbol);
                              setTimeframe(sig.timeframe);
                            }}
                            className="flex-1 py-1.5 px-2.5 text-xs font-mono font-semibold rounded bg-[#131B29] text-[#E2E8F0] border border-[#1E293B] hover:border-[#38BDF8] transition-colors cursor-pointer"
                          >
                            VER NO GRÁFICO REAL
                          </button>
                          <button
                            onClick={() => handleExecuteSignalTrade(sig)}
                            className={`flex-1 py-1.5 px-2.5 text-xs font-mono font-bold rounded transition-colors cursor-pointer ${
                              isBuy
                                ? "bg-[#00E676] text-[#070A0F] hover:bg-[#00E676]/90"
                                : "bg-[#FF2E54] text-white hover:bg-[#FF2E54]/90"
                            }`}
                          >
                            EXECUTAR {isBuy ? "COMPRA" : "VENDA"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
