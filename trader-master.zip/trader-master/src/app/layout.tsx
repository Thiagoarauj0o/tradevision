import type { Metadata } from "next";
import type { ReactNode } from "react";
import {
  Space_Grotesk,
  Plus_Jakarta_Sans,
  JetBrains_Mono,
} from "next/font/google";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  weight: ["600", "700"],
  variable: "--font-space-grotesk",
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-plus-jakarta",
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-jetbrains-mono",
});

export const metadata: Metadata = {
  title: "QUANTUM.AI // Terminal Gráfico 24/7 & Robô 1 de Sinais Financeiros",
  description:
    "Plataforma 24 horas de análise gráfica em tempo real, indicadores técnicos, oportunidades de compra e venda e Robô 1 com inteligência artificial e aprendizado contínuo dia-a-dia (Brasil & Mundo).",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html
      lang="pt-BR"
      className={`${spaceGrotesk.variable} ${plusJakarta.variable} ${jetbrainsMono.variable} dark`}
    >
      <body className="bg-[#070A0F] text-[#F8FAFC] antialiased selection:bg-[#38BDF8] selection:text-[#070A0F]">
        {children}
      </body>
    </html>
  );
}
