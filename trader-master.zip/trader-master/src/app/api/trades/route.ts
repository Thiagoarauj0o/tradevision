import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { userTrades, robotLearningLogs, tradingSignals } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureDatabaseInitialized } from "@/lib/market-engine";

export async function POST(request: NextRequest) {
  try {
    await ensureDatabaseInitialized();
    const body = await request.json();
    const { action } = body;

    if (action === "OPEN_TRADE") {
      const {
        assetSymbol,
        side,
        entryPrice,
        stopLoss,
        takeProfit,
        quantity,
        signalId,
        source,
      } = body;

      const [created] = await db
        .insert(userTrades)
        .values({
          assetSymbol: assetSymbol || "BTC/USDT",
          side: side || "COMPRA",
          entryPrice: Number(entryPrice) || 94280,
          stopLoss: Number(stopLoss) || 92950,
          takeProfit: Number(takeProfit) || 96400,
          quantity: Number(quantity) || 1,
          status: "ABERTA",
          pnlPercent: 0.35,
          signalId: signalId ? Number(signalId) : null,
          source: source || "ROBO_1",
        })
        .returning();

      return NextResponse.json({
        status: "ok",
        message: `Ordem de ${created.side} em ${created.assetSymbol} executada com sucesso no Terminal 24/7!`,
        trade: created,
      });
    }

    if (action === "CLOSE_TRADE") {
      const { tradeId, outcomePnl } = body;
      const pnlVal = Number(outcomePnl ?? 2.45);
      const isGain = pnlVal >= 0;

      const [updatedTrade] = await db
        .update(userTrades)
        .set({
          status: isGain ? "GAIN" : "LOSS",
          pnlPercent: pnlVal,
        })
        .where(eq(userTrades.id, Number(tradeId)))
        .returning();

      if (updatedTrade?.signalId) {
        await db
          .update(tradingSignals)
          .set({
            status: isGain ? "ALVO_ATINGIDO" : "STOP_ACIONADO",
            pnlPercent: pnlVal,
          })
          .where(eq(tradingSignals.id, updatedTrade.signalId));
      }

      // Feed result into Robô 1's daily reinforcement learning log
      const [latestLog] = await db
        .select()
        .from(robotLearningLogs)
        .orderBy(desc(robotLearningLogs.epochNumber))
        .limit(1);

      if (latestLog && updatedTrade) {
        const nextEpoch = latestLog.epochNumber + 1;
        const deltaWin = isGain ? 0.32 : -0.12;
        const nextWinRate = Number(
          Math.min(95.2, Math.max(60, latestLog.winRate + deltaWin)).toFixed(2)
        );

        await db.insert(robotLearningLogs).values({
          epochNumber: nextEpoch,
          dayLabel: `Ciclo #${nextEpoch} (Feedback ${updatedTrade.assetSymbol})`,
          winRate: nextWinRate,
          profitFactor: Number(
            (latestLog.profitFactor + (isGain ? 0.06 : -0.02)).toFixed(2)
          ),
          sharpeRatio: Number(
            (latestLog.sharpeRatio + (isGain ? 0.05 : -0.01)).toFixed(2)
          ),
          signalsEvaluated: latestLog.signalsEvaluated + 1,
          weightRsi: latestLog.weightRsi,
          weightMacd: latestLog.weightMacd,
          weightEma: Number(
            Math.min(0.28, latestLog.weightEma + 0.01).toFixed(2)
          ),
          weightBollinger: latestLog.weightBollinger,
          weightNewsBr: latestLog.weightNewsBr,
          weightNewsGlobal: latestLog.weightNewsGlobal,
          adaptationSummary: isGain
            ? `Feedback Positivo (+${pnlVal.toFixed(2)}% em ${updatedTrade.assetSymbol}): Robô 1 reforçou o padrão de entrada por confluência EMA + Notícias.`
            : `Ajuste de Risco (${pnlVal.toFixed(2)}% em ${updatedTrade.assetSymbol}): Robô 1 recalibrou o filtro de volatilidade ATR para evitar stops prematuros.`,
          triggerType: "FEEDBACK_OPERACAO",
        });
      }

      return NextResponse.json({
        status: "ok",
        message: `Operação encerrada (${pnlVal >= 0 ? "+" : ""}${pnlVal.toFixed(2)}%). Resultado enviado para o aprendizado contínuo do Robô 1!`,
        trade: updatedTrade,
      });
    }

    return NextResponse.json({ error: "Ação inválida" }, { status: 400 });
  } catch (error) {
    console.error("Error in POST /api/trades:", error);
    return NextResponse.json(
      { error: "Erro ao processar ordem financeira" },
      { status: 500 }
    );
  }
}
