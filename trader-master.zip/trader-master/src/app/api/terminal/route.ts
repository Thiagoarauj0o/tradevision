import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  assets,
  tradingSignals,
  newsEvents,
  robotLearningLogs,
  roboKnowledgeBooks,
  portalMarketFeeds,
  userTrades,
} from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import {
  ensureDatabaseInitialized,
  fetchRealMarketCandles,
  calculateFibonacciAndBookLevels,
  computeSuperOpportunities,
} from "@/lib/market-engine";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    await ensureDatabaseInitialized();

    const { searchParams } = new URL(request.url);
    const symbolParam = searchParams.get("symbol") || "IBOV";
    const timeframeParam = searchParams.get("timeframe") || "15m";

    const [
      allAssets,
      allSignals,
      allNews,
      allLearningLogs,
      allBooks,
      allPortalFeeds,
      allUserTrades,
    ] = await Promise.all([
      db.select().from(assets).orderBy(asc(assets.id)),
      db.select().from(tradingSignals).orderBy(desc(tradingSignals.id)).limit(20),
      db.select().from(newsEvents).orderBy(desc(newsEvents.id)).limit(25),
      db
        .select()
        .from(robotLearningLogs)
        .orderBy(asc(robotLearningLogs.epochNumber)),
      db
        .select()
        .from(roboKnowledgeBooks)
        .orderBy(asc(roboKnowledgeBooks.id)),
      db
        .select()
        .from(portalMarketFeeds)
        .orderBy(desc(portalMarketFeeds.id))
        .limit(20),
      db.select().from(userTrades).orderBy(desc(userTrades.id)).limit(20),
    ]);

    const activeAsset =
      allAssets.find((a) => a.symbol === symbolParam) || allAssets[0];

    const candles = activeAsset
      ? await fetchRealMarketCandles(
          activeAsset.symbol,
          activeAsset.price,
          activeAsset.volatility,
          timeframeParam,
          96
        )
      : [];

    if (activeAsset && candles.length > 0) {
      const latestCandle = candles[candles.length - 1];
      activeAsset.price = latestCandle.close;
      activeAsset.rsi14 = Number(latestCandle.rsi14.toFixed(1));
      activeAsset.macdHist = Number(latestCandle.macdHist.toFixed(2));

      await db
        .update(assets)
        .set({
          price: latestCandle.close,
          rsi14: activeAsset.rsi14,
          macdHist: activeAsset.macdHist,
        })
        .where(eq(assets.id, activeAsset.id));
    }

    const fiboLevels = calculateFibonacciAndBookLevels(candles);
    const superOpportunities = computeSuperOpportunities(allAssets);

    return NextResponse.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      activeSymbol: activeAsset?.symbol || symbolParam,
      timeframe: timeframeParam,
      assets: allAssets,
      signals: allSignals,
      news: allNews,
      learningLogs: allLearningLogs,
      knowledgeBooks: allBooks,
      portalFeeds: allPortalFeeds,
      superOpportunities,
      userTrades: allUserTrades,
      candles,
      fiboLevels,
    });
  } catch (error) {
    console.error("Error in GET /api/terminal:", error);
    return NextResponse.json(
      { error: "Falha ao carregar dados do terminal 24/7" },
      { status: 500 }
    );
  }
}
