import {
  pgTable,
  serial,
  text,
  doublePrecision,
  integer,
  timestamp,
} from "drizzle-orm/pg-core";

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  category: text("category").notNull(), // 'BRASIL_B3' | 'CRIPTO_24H' | 'GLOBAL_US' | 'CAMBIO'
  currency: text("currency").notNull(), // 'R$' | 'US$' | 'PTS'
  price: doublePrecision("price").notNull(),
  change24h: doublePrecision("change_24h").notNull(),
  high24h: doublePrecision("high_24h").notNull(),
  low24h: doublePrecision("low_24h").notNull(),
  volume24h: text("volume_24h").notNull(),
  volatility: doublePrecision("volatility").notNull(),
  rsi14: doublePrecision("rsi_14").notNull(),
  macdHist: doublePrecision("macd_hist").notNull(),
  emaTrend: text("ema_trend").notNull(), // 'ALTA_FORTE' | 'ALTA' | 'LATERAL' | 'BAIXA' | 'BAIXA_FORTE'
  aiBias: text("ai_bias").notNull(), // 'COMPRA FORTE' | 'VENDA FORTE' | 'COMPRA' | 'VENDA' | 'NEUTRO'
  aiConfidence: integer("ai_confidence").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const tradingSignals = pgTable("trading_signals", {
  id: serial("id").primaryKey(),
  assetSymbol: text("asset_symbol").notNull(),
  assetName: text("asset_name").notNull(),
  marketRegion: text("market_region").notNull(), // 'BRASIL' | 'GLOBAL' | 'CRIPTO 24/7'
  direction: text("direction").notNull(), // 'COMPRA FORTE' | 'VENDA FORTE' | 'COMPRA' | 'VENDA'
  timeframe: text("timeframe").notNull(), // '5m' | '15m' | '1h' | '4h' | '1D'
  entryPrice: doublePrecision("entry_price").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit1: doublePrecision("take_profit_1").notNull(),
  takeProfit2: doublePrecision("take_profit_2").notNull(),
  riskReward: text("risk_reward").notNull(), // e.g., '1:3.2'
  confidenceScore: integer("confidence_score").notNull(), // 0 - 100
  technicalConfluence: text("technical_confluence").notNull(),
  newsCatalyst: text("news_catalyst").notNull(),
  roboLearningNote: text("robo_learning_note").notNull(),
  status: text("status").notNull().default("ATIVO"), // 'ATIVO' | 'ALVO_ATINGIDO' | 'STOP_ACIONADO'
  pnlPercent: doublePrecision("pnl_percent").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const newsEvents = pgTable("news_events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  source: text("source").notNull(),
  region: text("region").notNull(), // 'BRASIL' | 'MUNDO'
  impactLevel: text("impact_level").notNull(), // 'ALTO' | 'MEDIO' | 'BAIXO'
  sentiment: text("sentiment").notNull(), // 'BULLISH' | 'BEARISH' | 'NEUTRAL'
  sentimentScore: integer("sentiment_score").notNull(), // -100 to +100
  relatedAssets: text("related_assets").notNull(), // e.g., 'PETR4,WINJ26,USD/BRL'
  aiAnalysis: text("ai_analysis").notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});

export const robotLearningLogs = pgTable("robot_learning_logs", {
  id: serial("id").primaryKey(),
  epochNumber: integer("epoch_number").notNull(),
  dayLabel: text("day_label").notNull(),
  winRate: doublePrecision("win_rate").notNull(),
  profitFactor: doublePrecision("profit_factor").notNull(),
  sharpeRatio: doublePrecision("sharpe_ratio").notNull(),
  signalsEvaluated: integer("signals_evaluated").notNull(),
  weightRsi: doublePrecision("weight_rsi").notNull(),
  weightMacd: doublePrecision("weight_macd").notNull(),
  weightEma: doublePrecision("weight_ema").notNull(),
  weightBollinger: doublePrecision("weight_bollinger").notNull(),
  weightNewsBr: doublePrecision("weight_news_br").notNull(),
  weightNewsGlobal: doublePrecision("weight_news_global").notNull(),
  adaptationSummary: text("adaptation_summary").notNull(),
  triggerType: text("trigger_type").notNull(), // 'CICLO_DIARIO' | 'RECALIBRACAO_IA' | 'FEEDBACK_OPERACAO' | 'TREINO_LITERATURA' | 'SYNC_PORTAIS'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const roboKnowledgeBooks = pgTable("robo_knowledge_books", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // 'MURPHY' | 'ELDER' | 'LEFEVRE' | 'BULKOWSKI' | 'FLAVIO_LEMOS' | 'TURTLE_FAITH' | 'WALKER_FIBO'
  title: text("title").notNull(),
  author: text("author").notNull(),
  coreMethod: text("core_method").notNull(),
  quantitativeRules: text("quantitative_rules").notNull(),
  roboImplementation: text("robo_implementation").notNull(),
  chartIndicatorTag: text("chart_indicator_tag").notNull(),
  masteryPercent: doublePrecision("mastery_percent").notNull().default(96.5),
  neuralWeight: doublePrecision("neural_weight").notNull().default(0.14),
  patternsValidated: integer("patterns_validated").notNull().default(240),
  winRateBoost: doublePrecision("win_rate_boost").notNull().default(3.2),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const portalMarketFeeds = pgTable("portal_market_feeds", {
  id: serial("id").primaryKey(),
  portalCode: text("portal_code").notNull(), // 'INFOMONEY_IBOV' | 'B3_OFICIAL_IBOV' | 'INVESTING_BR_BOVESPA'
  portalName: text("portal_name").notNull(),
  sourceUrl: text("source_url").notNull(),
  headline: text("headline").notNull(),
  marketMetricLabel: text("market_metric_label").notNull(),
  marketMetricValue: text("market_metric_value").notNull(),
  technicalConsensus: text("technical_consensus").notNull(), // 'COMPRA FORTE' | 'VENDA FORTE' | 'COMPRA' | 'VENDA'
  sentimentScore: integer("sentiment_score").notNull(), // -100 to +100
  impactedTickers: text("impacted_tickers").notNull(),
  opportunityAction: text("opportunity_action").notNull(),
  bookConfluenceRef: text("book_confluence_ref").notNull(),
  syncedAt: timestamp("synced_at").defaultNow().notNull(),
});

export const userTrades = pgTable("user_trades", {
  id: serial("id").primaryKey(),
  assetSymbol: text("asset_symbol").notNull(),
  side: text("side").notNull(), // 'COMPRA' | 'VENDA'
  entryPrice: doublePrecision("entry_price").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  quantity: doublePrecision("quantity").notNull(),
  status: text("status").notNull().default("ABERTA"), // 'ABERTA' | 'GAIN' | 'LOSS'
  pnlPercent: doublePrecision("pnl_percent").notNull().default(0),
  signalId: integer("signal_id"),
  source: text("source").notNull().default("ROBO_1"), // 'ROBO_1' | 'MANUAL'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
